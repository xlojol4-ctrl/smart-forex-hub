import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import type { 
  User, Course, Lesson, Tutorial, ResourceItem, TradeRecord, 
  EconomicEvent, CommunityPost, CommunityComment, PlatformAnnouncement 
} from '../src/types/index.ts';

const DB_FILE = path.resolve(process.cwd(), 'data', 'db.json');

export interface DatabaseSchema {
  users: (User & { passwordHash: string })[];
  courses: Course[];
  lessons: Lesson[];
  tutorials: Tutorial[];
  resources: ResourceItem[];
  trades: TradeRecord[];
  events: EconomicEvent[];
  communityPosts: CommunityPost[];
  comments: CommunityComment[];
  announcements: PlatformAnnouncement[];
}

function hashPassword(pass: string): string {
  return crypto.createHash('sha256').update(pass + '_smartforex_salt_2026').digest('hex');
}

export function verifyPassword(input: string, storedHash: string): boolean {
  return hashPassword(input) === storedHash;
}

const INITIAL_COURSES: Course[] = [
  {
    id: 'course-1',
    titleEn: 'Forex Fundamentals & Core Basics',
    titleBn: 'ফরেক্স বেসিক ও প্রাথমিক ধারণা',
    slug: 'forex-fundamentals',
    difficulty: 'beginner',
    summaryEn: 'Master the currency market mechanics, currency pairs, pips, lots, leverage, and margin.',
    summaryBn: 'মুদ্রা বাজারের কাঠামো, কারেন্সি পেয়ার, পিপ্স, লট, লিভারেজ এবং মার্জিনের খুঁটিনাটি শিখুন।',
    icon: 'TrendingUp',
    order: 1,
    isPublished: true,
    lessonsCount: 5,
  },
  {
    id: 'course-2',
    titleEn: 'Technical Analysis & Chart Mastery',
    titleBn: 'টেকনিক্যাল এনালাইসিস ও চার্ট মাস্টারি',
    slug: 'technical-analysis',
    difficulty: 'intermediate',
    summaryEn: 'Understand price action, Japanese candlesticks, support/resistance, and reliable chart patterns.',
    summaryBn: 'প্রাইস অ্যাকশন, ক্যান্ডেলস্টিক প্যাটার্ন, সাপোর্ট-রেজিস্ট্যান্স এবং চার্ট স্ট্রাকচার নির্ভুলভাবে বুঝুন।',
    icon: 'BarChart3',
    order: 2,
    isPublished: true,
    lessonsCount: 5,
  },
  {
    id: 'course-3',
    titleEn: 'Fundamental Analysis & Macro Events',
    titleBn: 'ফান্ডামেন্টাল এনালাইসিস ও বৈশ্বিক খবর',
    slug: 'fundamental-analysis',
    difficulty: 'intermediate',
    summaryEn: 'Learn how central banks, interest rate decisions, CPI inflation, and NFP drive exchange rates.',
    summaryBn: 'সেন্ট্রাল ব্যাংক, সুদের হার, মুদ্রাস্ফীতি (CPI) এবং NFP কিভাবে কারেন্সি বাজারে প্রভাব ফেলে তা জানুন।',
    icon: 'Globe',
    order: 3,
    isPublished: true,
    lessonsCount: 3,
  },
  {
    id: 'course-4',
    titleEn: 'Risk Management & Trading Psychology',
    titleBn: 'রিস্ক ম্যানেজমেন্ট ও ট্রেডিং সাইকোলজি',
    slug: 'risk-and-psychology',
    difficulty: 'advanced',
    summaryEn: 'Protect capital with position sizing rules, overcome FOMO, and build high-probability discipline.',
    summaryBn: 'মূলধন সুরক্ষিত রাখার নিয়ম, ফোমো (FOMO) নিয়ন্ত্রণ এবং সফল ট্রেডারের মানসিক শৃঙ্খলা তৈরি করুন।',
    icon: 'ShieldCheck',
    order: 4,
    isPublished: true,
    lessonsCount: 4,
  },
];

const INITIAL_LESSONS: Lesson[] = [
  {
    id: 'les-1-1',
    courseId: 'course-1',
    titleEn: 'What is Forex & How Currency Pairs Work',
    titleBn: 'ফরেক্স কি এবং কারেন্সি পেয়ার কিভাবে কাজ করে?',
    slug: 'what-is-forex',
    difficulty: 'beginner',
    readTimeMinutes: 6,
    order: 1,
    summaryEn: 'An introduction to the $7.5 trillion daily global currency exchange market and currency quoting.',
    summaryBn: 'দৈনিক ৭.৫ ট্রিলিয়ন ডলারের বৈশ্বিক মুদ্রা বাজার এবং কারেন্সি কোটেশনের সহজ সূচনা।',
    contentEn: `### 1. What is Forex?
Forex (Foreign Exchange or FX) is the decentralized worldwide market where fiat currencies are traded against one another. It operates 24 hours a day, 5 days a week across major financial hubs: Sydney, Tokyo, London, and New York.

### 2. The Mechanics of Currency Pairs
Currencies are always quoted in pairs, for example **EUR/USD**:
- **Base Currency** (First currency): **EUR** (Euro).
- **Quote / Counter Currency** (Second currency): **USD** (US Dollar).

If EUR/USD is trading at **1.0850**, it means:
> 1 Euro = 1.0850 US Dollars.

- If you believe the Euro will strengthen against the Dollar, you **BUY (Go Long)**.
- If you believe the Euro will weaken against the Dollar, you **SELL (Go Short)**.

### 3. Pair Classifications
1. **Majors**: Pairs that include the USD against major global currencies (EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD). These have the highest liquidity and lowest broker spreads.
2. **Minors (Crosses)**: Major currencies without the USD (EUR/GBP, EUR/JPY, GBP/JPY).
3. **Exotics**: A major currency paired with a developing economy's currency (USD/TRY, USD/ZAR). Higher spreads and higher volatility.`,
    contentBn: `### ১. ফরেক্স কি?
ফরেক্স (Foreign Exchange) হলো বিশ্বব্যাপী বিকেন্দ্রীভূত বৈদেশিক মুদ্রা বিনিময় বাজার। প্রতিদিন এখানে প্রায় ৭.৫ ট্রিলিয়ন ডলারের বেশি লেনদেন হয়। বাজারটি সপ্তাহে ৫ দিন, ২৪ ঘণ্টা সিডনি, টোকিও, লন্ডন এবং নিউ ইয়র্ক সেশনের মাধ্যমে খোলা থাকে।

### ২. কারেন্সি পেয়ার কিভাবে কাজ করে?
মুদ্রা সবসময় জোড়ায় (Pair) কেনাবেচা হয়, যেমন **EUR/USD**:
- **বেস কারেন্সি (Base Currency)**: প্রথম মুদ্রা — **EUR** (ইউরো)।
- **কোট কারেন্সি (Quote Currency)**: দ্বিতীয় মুদ্রা — **USD** (ইউএস ডলার)।

EUR/USD এর বর্তমান মূল্য যদি **১.০৮৫০** হয়, তার অর্থ:
> ১ ইউরো কিনতে ১.০৮৫০ ইউএস ডলার প্রয়োজন।

- ইউরো শক্তিশালী হবে মনে করলে আপনি **BUY (লং)** করবেন।
- ইউরো দুর্বল হবে মনে করলে আপনি **SELL (শর্ট)** করবেন।

### ৩. পেয়ারের প্রকারভেদ
১. **মেজর পেয়ার (Majors)**: যাতে USD থাকে (EUR/USD, GBP/USD, USD/JPY)। এগুলোতে স্প্রেড সবচেয়ে কম এবং তারল্য সবচেয়ে বেশি।
২. **মাইনর বা ক্রস পেয়ার (Minors)**: যেখানে USD নেই (EUR/GBP, GBP/JPY)।
৩. **এক্সোটিক পেয়ার (Exotics)**: একটি মেজর ও একটি উদীয়মান দেশের মুদ্রা (USD/ZAR, USD/TRY)। এগুলোতে স্প্রেড ও ঝুঁকি বেশি।`,
    keyTakeawaysEn: [
      'Forex is a bilateral exchange market trading 24/5.',
      'Base currency is what you buy or sell; quote currency is the price measurement.',
      'Major pairs offer lowest trading costs and greatest market depth.'
    ],
    keyTakeawaysBn: [
      'ফরেক্স সপ্তাহে ৫ দিন ২৪ ঘণ্টা পরিচালিত আন্তর্জাতিক মুদ্রা বাজার।',
      'বেস কারেন্সি কেনাবেচা হয় এবং কোট কারেন্সি দিয়ে দাম নির্ধারিত হয়।',
      'মেজর পেয়ারগুলোতে স্প্রেড সবচেয়ে কম ও বিশ্বস্ত গতি থাকে।'
    ],
    quiz: [
      {
        id: 'q-1',
        questionEn: 'In the GBP/USD pair, which currency is the Base currency?',
        questionBn: 'GBP/USD পেয়ারে কোন মুদ্রাটি বেস (Base) কারেন্সি?',
        optionsEn: ['USD', 'GBP', 'Both', 'Neither'],
        optionsBn: ['USD', 'GBP', 'উভয়ই', 'কোনটিই নয়'],
        correctAnswer: 1,
        explanationEn: 'The first currency in any Forex pair quotation is always the Base currency (GBP here).',
        explanationBn: 'যেকোনো কারেন্সি কোটেশনে প্রথম মুদ্রাটি সর্বদা বেস কারেন্সি (এখানে GBP)।'
      },
      {
        id: 'q-2',
        questionEn: 'If EUR/USD is 1.0800 and rises to 1.0850, what happened?',
        questionBn: 'যদি EUR/USD ১.০৮০০ থেকে ১.০৮৫০ এ ওঠে, তবে কি ঘটেছে?',
        optionsEn: ['EUR weakened against USD', 'EUR strengthened against USD', 'USD gained value', 'Market crashed'],
        optionsBn: ['ইউরো দুর্বল হয়েছে', 'ইউরো ডলারের বিপরীতে শক্তিশালী হয়েছে', 'ডলারের দাম বেড়েছে', 'মার্কেট বন্ধ হয়েছে'],
        correctAnswer: 1,
        explanationEn: 'When the exchange rate increases, the base currency (EUR) has gained value relative to the quote currency (USD).',
        explanationBn: 'মূল্য বৃদ্ধি পাওয়ার অর্থ হলো বেস কারেন্সি (EUR) কোট কারেন্সির (USD) তুলনায় শক্তিশালী হয়েছে।'
      }
    ],
    isPublished: true,
    createdAt: '2026-01-10T10:00:00Z',
  },
  {
    id: 'les-1-2',
    courseId: 'course-1',
    titleEn: 'Pips, Pipettes, Spreads, and Lot Sizes',
    titleBn: 'পিপ্স, পিপেটস, স্প্রেড এবং লট সাইজ',
    slug: 'pips-spread-lot-sizes',
    difficulty: 'beginner',
    readTimeMinutes: 7,
    order: 2,
    summaryEn: 'Understand how market price movement is counted in pips and how lot sizes determine financial impact.',
    summaryBn: 'মার্কেট মুভমেন্ট পিপ্সে কিভাবে গণনা করা হয় এবং লট সাইজ কিভাবে লাভ-লোকসান নির্ধারণ করে জানুন।',
    contentEn: `### 1. What is a Pip?
A **Pip** stands for *"Percentage in Point"* or *"Price Interest Point"*. It is the standard unit of measurement for exchange rate movement.
- For most pairs (4 decimal places): 1 Pip = **0.0001**.
  Example: EUR/USD moving from 1.0820 to 1.0825 is a move of **5 pips**.
- For Japanese Yen pairs (2 decimal places): 1 Pip = **0.01**.
  Example: USD/JPY moving from 150.20 to 150.35 is a move of **15 pips**.

A **Pipette** is a fractional pip (1/10th of a pip), shown as the 5th decimal digit.

### 2. Bid, Ask & The Spread
- **Bid Price**: The price at which you can SELL.
- **Ask Price**: The price at which you can BUY.
- **Spread**: The difference between Ask and Bid.
> Spread = Ask Price - Bid Price.
This represents the primary transaction fee charged by brokers.

### 3. Lot Sizes Explained
In Forex, volume is executed in **Lots**:
- **Standard Lot (1.00)** = 100,000 units of base currency. Pip value ~ $10 on EUR/USD.
- **Mini Lot (0.10)** = 10,000 units of base currency. Pip value ~ $1.00 on EUR/USD.
- **Micro Lot (0.01)** = 1,000 units of base currency. Pip value ~ $0.10 on EUR/USD.

*Golden Rule*: Beginners should always start with 0.01 micro lots to protect capital!`,
    contentBn: `### ১. পিপ (Pip) কি?
**Pip** হলো *"Percentage in Point"*-এর সংক্ষিপ্ত রূপ। কারেন্সি পেয়ারের মূল্যের ক্ষুদ্রতম পরিবর্তন পরিমাপের একক।
- সাধারণ পেয়ারে (৪ দশমিক স্থান): ১ পিপ = **০.০০০১**।
  যেমন: EUR/USD ১.০৮২০ থেকে ১.০৮২৫ হলে এটি **৫ পিপ** বৃদ্ধি।
- জাপানি ইয়েন (JPY) পেয়ারে (২ দশমিক স্থান): ১ পিপ = **০.০১**।
  যেমন: USD/JPY ১৫০.২০ থেকে ১৫০.৩৫ হলে এটি **১৫ পিপ** পরিবর্তন।

### ২. বিড, আস্ক এবং স্প্রেড
- **Bid Price**: যে দামে আপনি সেল (Sell) করতে পারেন।
- **Ask Price**: যে দামে আপনি বাই (Buy) করতে পারেন।
- **Spread**: আস্ক ও বিড প্রাইসের মধ্যবর্তী পার্থক্য। এটি ব্রোকারের কমিশন।

### ৩. লট সাইজ (Lot Sizes)
ফরেক্সে ট্রেডের পরিমাণ লটে প্রকাশ করা হয়:
- **স্ট্যান্ডার্ড লট (১.০০)**: ১০০,০০০ ইউনিট। প্রতি পিপ মূল্য প্রায় $১০ ডলার (EUR/USD)।
- **মিনি লট (০.১০)**: ১০,০০০ ইউনিট। প্রতি পিপ মূল্য প্রায় $১.০০ ডলার।
- **মাইক্রো লট (০.০১)**: ১,০০০ ইউনিট। প্রতি পিপ মূল্য প্রায় $০.১০ ডলার (১০ সেন্ট)।

*নতুনদের পরামর্শ*: সবসময় ০.০১ মাইক্রো লট দিয়ে শুরু করুন যেন ঝুঁকি নিয়ন্ত্রণে থাকে।`,
    keyTakeawaysEn: [
      '1 Pip = 0.0001 on most pairs, 0.01 on JPY pairs.',
      'Spread is Ask minus Bid (broker execution cost).',
      '0.01 lot = $0.10 per pip; 1.00 lot = $10.00 per pip on EUR/USD.'
    ],
    keyTakeawaysBn: [
      'বেশিরভাগ পেয়ারে ১ পিপ = ০.০০০১, আর JPY পেয়ারে ১ পিপ = ০.০১।',
      'স্প্রেড হলো আস্ক এবং বিডের তফাত (ব্রোকারের ফি)।',
      '০.০১ লটে প্রতি পিপের প্রভাব প্রায় $০.১০ ডলার।'
    ],
    quiz: [
      {
        id: 'q-2-1',
        questionEn: 'If EUR/USD moves from 1.0900 to 1.0930, how many pips did it gain?',
        questionBn: 'EUR/USD যদি ১.০৯০০ থেকে ১.০৯৩০ হয়, তবে কত পিপ লাভ হলো?',
        optionsEn: ['3 pips', '30 pips', '300 pips', '0.3 pips'],
        optionsBn: ['৩ পিপ', '৩০ পিপ', '৩০০ পিপ', '০.৩ পিপ'],
        correctAnswer: 1,
        explanationEn: '1.0930 - 1.0900 = 0.0030 = 30 pips.',
        explanationBn: '১.০৯৩০ - ১.০৯০০ = ০.০০৩০ = ৩০ পিপ।'
      }
    ],
    isPublished: true,
    createdAt: '2026-01-11T10:00:00Z',
  },
  {
    id: 'les-1-3',
    courseId: 'course-1',
    titleEn: 'Leverage, Margin, and Margin Calls Explained',
    titleBn: 'লিভারেজ, মার্জিন এবং মার্জিন কল কি?',
    slug: 'leverage-margin-margin-call',
    difficulty: 'beginner',
    readTimeMinutes: 8,
    order: 3,
    summaryEn: 'Understand how broker borrowing power works, why high leverage is a double-edged sword, and how to avoid liquidation.',
    summaryBn: 'ব্রোকার প্রদত্ত ঋণ সুবিধা, উচ্চ লিভারেজের গোপন বিপদ এবং অ্যাকাউন্ট ওয়াইপআউট থেকে বাঁচার উপায়।',
    contentEn: `### 1. What is Leverage?
Leverage allows you to control a large trading position with a relatively small deposit.
For example, **1:100 leverage** means:
> With $100 of your own money, you can control $10,000 worth of currency.

### 2. What is Margin?
Margin is NOT a fee; it is good-faith collateral locked by the broker while your trade remains open.
- Formula:
  $$\\text{Required Margin} = \\frac{\\text{Trade Volume (Units)}}{\\text{Leverage}}$$
Example: Buying 1 Mini Lot (10,000 EUR) on EUR/USD at 1:100 leverage requires **100 EUR** as locked margin.

### 3. Free Margin & Margin Level
- **Equity**: Balance + Floating Profit/Loss.
- **Free Margin**: Equity - Used Margin. (Money available to open new trades).
- **Margin Level (%)**: (Equity / Used Margin) * 100.

### 4. Margin Call & Stop Out
When trades go against you and Margin Level drops:
- **Margin Call (typically 60%)**: Broker alerts you to deposit funds or close positions.
- **Stop Out (typically 0% - 20% on Exness/retail brokers)**: Broker automatically forcibly liquidates losing positions to prevent negative balance.

*Warning*: High leverage amplifies both profits and losses equally!`,
    contentBn: `### ১. লিভারেজ কি?
লিভারেজ হলো ব্রোকারের দেওয়া ঋণ সুবিধা যার মাধ্যমে আপনি সামান্য ডিপোজিট দিয়ে বড় আকারের ট্রেড পরিচালনা করতে পারেন।
উদাহরণস্বরূপ **১:১০০ লিভারেজ**-এর মানে:
> আপনার নিজের $১০০ ডলার দিয়ে আপনি $১০,০০০ ডলার মূল্যের পজিশন নিয়ন্ত্রণ করতে পারবেন।

### ২. মার্জিন (Margin) কি?
মার্জিন কোনো ফি নয়; এটি ট্রেড চলাকালীন ব্রোকার কর্তৃক সাময়িক জমা রাখা নিরাপত্তা জামানত।
ফর্মুলা: **প্রয়োজনীয় মার্জিন = ট্রেডের সাইজ / লিভারেজ**।
১ মিনি লট (১০,০০০ ইউরো) ট্রেড করতে ১:১০০ লিভারেজে জামানত লাগবে মাত্র **১০০ ইউরো**।

### ৩. মার্জিন কল ও স্টপ আউট
ট্রেডে বড় লস হলে মার্জিন লেভেল নিচে নামতে থাকে:
- **মার্জিন কল**: ব্রোকার সতর্কবার্তা দেয় যে ব্যালেন্স শেষ হয়ে আসছে।
- **স্টপ আউট**: মার্জিন লেভেল সর্বনিম্ন সীমায় নামলে ব্রোকার স্বয়ংক্রিয়ভাবে আপনার লসের ট্রেড কেটে অ্যাকাউন্ট বন্ধ করে দেয়।`,
    keyTakeawaysEn: [
      'Leverage is borrowing capacity that magnifies both profits and risks.',
      'Margin is locked collateral, not a payment.',
      'Never trade without a Stop Loss to avoid margin calls.'
    ],
    keyTakeawaysBn: [
      'লিভারেজ লাভ ও ক্ষতি উভয়কেই বহুগুণ বাড়িয়ে দেয়।',
      'মার্জিন হলো আপনার ট্রেড চালু রাখার নিরাপত্তা জামানত।',
      'মার্জিন কল এড়াতে সবসময় স্টপ লস (Stop Loss) ব্যবহার করুন।'
    ],
    quiz: [
      {
        id: 'q-3-1',
        questionEn: 'What happens when your broker triggers a Stop Out?',
        questionBn: 'ব্রোকার স্টপ আউট ট্রিগার করলে কি ঘটে?',
        optionsEn: ['Broker adds bonus credit', 'Broker forcibly closes losing trades', 'Profits double', 'The market closes'],
        optionsBn: ['ব্রোকার বোনাস দেয়', 'ব্রোকার স্বয়ংক্রিয়ভাবে লস ট্রেড বন্ধ করে দেয়', 'লাভ দ্বিগুণ হয়', 'মার্কেট বন্ধ হয়'],
        correctAnswer: 1,
        explanationEn: 'Stop out is the automatic forced closure of open trades to protect against negative equity.',
        explanationBn: 'স্টপ আউট হলো মূলধন ঋণাত্মক হওয়া ঠেকাতে ব্রোকারের স্বয়ংক্রিয়ভাবে ট্রেড কেটে দেওয়া।'
      }
    ],
    isPublished: true,
    createdAt: '2026-01-12T10:00:00Z',
  },
  {
    id: 'les-2-1',
    courseId: 'course-2',
    titleEn: 'Reading Japanese Candlesticks & Price Action',
    titleBn: 'জাপানি ক্যান্ডেলস্টিক ও প্রাইস অ্যাকশন পাঠ',
    slug: 'japanese-candlesticks-price-action',
    difficulty: 'intermediate',
    readTimeMinutes: 9,
    order: 1,
    summaryEn: 'Anatomy of candles, bullish/bearish engulfing, pin bars, and reading buyer vs seller exhaustion.',
    summaryBn: 'ক্যান্ডেলের গঠন, বুলিশ ও বিয়ারিশ এনগালফিং, পিন বার এবং ক্রেতা-বিক্রেতার লড়াই বিশ্লেষণ।',
    contentEn: `### 1. Anatomy of a Candlestick
Every Japanese candlestick reveals 4 vital data points over a given timeframe (Open, High, Low, Close - OHLC):
- **Body**: Distance between Open and Close.
  - Green / Bullish: Close > Open (Buyers won).
  - Red / Bearish: Close < Open (Sellers won).
- **Upper Shadow (Wick)**: Price rejection from highs.
- **Lower Shadow (Wick)**: Price rejection from lows.

### 2. High-Probability Reversal Patterns
1. **The Pin Bar (Hammer / Shooting Star)**:
   - Long rejection wick (at least 2/3 of the entire candle).
   - Small body at the opposite end.
   - Signals rejection of a price zone.
2. **Bullish & Bearish Engulfing**:
   - Candle 2 completely swallows the body of Candle 1.
   - Shows aggressive momentum takeover by opposing market participants.
3. **Doji**:
   - Open and close are almost identical.
   - Shows market indecision and potential turning point.`,
    contentBn: `### ১. ক্যান্ডেলস্টিকের মৌলিক গঠন
প্রতিটি জাপানি ক্যান্ডেলে নির্দিষ্ট সময়ের ৪টি তথ্য থাকে (OHLC):
- **ওপেন (Open)**: সময়সীমার শুরুর মূল্য।
- **হাই (High)**: সর্বোচ্চ অর্জিত মূল্য।
- **লো (Low)**: সর্বনিম্ন অর্জিত মূল্য।
- **ক্লোজ (Close)**: শেষ মূল্য।

### ২. শক্তিশালী রিভার্সাল প্যাটার্ন
১. **পিন বার বা হ্যামার (Pin Bar / Hammer)**:
   - দীর্ঘ রিজেকশন উইক (ক্যান্ডেলের প্রায় দুই-তৃতীয়াংশ)।
   - প্রমাণ করে যে এক পক্ষ দাম টেনে নামালেও অপর পক্ষ প্রবল শক্তিতে তা ফিরিয়ে নিয়েছে।
২. **এনগালফিং (Engulfing)**:
   - পরবর্তী ক্যান্ডেলটি পূর্ববর্তী ক্যান্ডেলের পুরো শরীরকে ঢেকে ফেলে।
   - বুলিশ এনগালফিং ক্রয়ের প্রবল শক্তির নির্দেশক।
৩. **ডোজি (Doji)**:
   - ওপেন ও ক্লোজ প্রাইস প্রায় সমান। এটি বাজারে সিদ্ধান্তহীনতা প্রকাশ করে।`,
    keyTakeawaysEn: [
      'Candles illustrate the ongoing auction between buyers and sellers.',
      'Wicks indicate rejection and liquidity sweep.',
      'Always trade candle patterns at major Support and Resistance levels, never in isolation.'
    ],
    keyTakeawaysBn: [
      'ক্যান্ডেলস্টিক ক্রেতা ও বিক্রেতার মনস্তাত্ত্বিক যুদ্ধ প্রকাশ করে।',
      'লম্বা উইক মূল্য প্রত্যাখানের স্পষ্ট প্রমাণ।',
      'কেবলমাত্র মূল সাপোর্ট বা রেজিস্ট্যান্সে ক্যান্ডেলস্টিক সিগন্যাল কার্যকর।'
    ],
    quiz: [
      {
        id: 'q-21-1',
        questionEn: 'What does a long lower wick on a candle indicate?',
        questionBn: 'একটি ক্যান্ডেলের নিচের দিকে দীর্ঘ উইক কি নির্দেশ করে?',
        optionsEn: ['Sellers completely dominated the close', 'Buyers rejected lower prices aggressively', 'Market volume is zero', 'The trade will fail'],
        optionsBn: ['বিক্রেতারা বাজার দখল করেছে', 'ক্রেতারা নিচের দাম প্রত্যাখ্যান করে উপরে এনেছে', 'ভলিউম শূন্য', 'ট্রেড বাতিল'],
        correctAnswer: 1,
        explanationEn: 'A long lower wick shows sellers drove prices down, but buyers stepped in aggressively to push prices back up.',
        explanationBn: 'নিচের লম্বা উইক বোঝায় বিক্রেতারা দাম নামালেও শক্তিশালী ক্রেতারা তা প্রতিরোধ করে উপরে তুলেছে।'
      }
    ],
    isPublished: true,
    createdAt: '2026-01-13T10:00:00Z',
  },
  {
    id: 'les-4-1',
    courseId: 'course-4',
    titleEn: 'The 1% Risk Rule and Position Sizing Math',
    titleBn: '১% ক্যাপিটাল রিস্ক রুল ও পজিশন সাইজিং',
    slug: 'the-one-percent-risk-rule',
    difficulty: 'advanced',
    readTimeMinutes: 8,
    order: 1,
    summaryEn: 'How math ensures survival: never risking more than 1% to 2% per trade, and calculating lot sizes correctly.',
    summaryBn: 'গণিতের সাহায্যে মূলধন রক্ষা: প্রতি ট্রেডে ১% থেকে ২% এর বেশি ঝুঁকি না নেওয়ার কৌশল।',
    contentEn: `### 1. Why Traders Blow Accounts
Most retail traders do not fail because of bad analysis — they fail due to improper **position sizing** and **risk management**.
- If you risk 10% per trade, **4 consecutive losses** drops your balance by **35%**, requiring a **54% gain** just to get back to breakeven!
- If you risk 1% per trade, 4 consecutive losses drops your balance by only **3.9%**, requiring only **4% gain** to recover.

### 2. The Strict Position Sizing Formula
Never pick lot sizes randomly (e.g. "I always use 0.5 lot").
1. Calculate your Dollar Risk:
   $$\\text{Dollar Risk} = \\text{Account Balance} \\times \\text{Risk \\%}$$
   Example: On a $5,000 account at 1% risk = **$50.00**.
2. Measure your Stop Loss in Pips (e.g., 25 pips based on technical chart structure).
3. Compute exact Lot Size:
   $$\\text{Lot Size} = \\frac{\\text{Dollar Risk}}{\\text{Stop Loss Pips} \\times \\text{Pip Value per Standard Lot}}$$
   $$\\text{Lot Size} = \\frac{\\$50}{25 \\times \\$10} = 0.20 \\text{ Lots}.$$`,
    contentBn: `### ১. ট্রেডাররা কেন অ্যাকাউন্ট জিরো করে?
বেশিরভাগ ট্রেডার খারাপ অ্যানালাইসিসের কারণে ব্যর্থ হয় না, ব্যর্থ হয় সঠিক রিস্ক ম্যানেজমেন্ট না থাকার কারণে।
- প্রতি ট্রেডে ১০% ঝুঁকি নিলে টানা ৪টি লসে আপনার অ্যাকাউন্টের **৩৫% শেষ** হয়ে যায়, যা পুনরুদ্ধার করতে ৫৪% লাভ করতে হবে!
- প্রতি ট্রেডে ১% ঝুঁকি নিলে টানা ৪টি লসে অ্যাকাউন্ট হারায় মাত্র **৩.৯%**, যা সহজে রিকভার করা সম্ভব।

### ২. সঠিক পজিশন সাইজিং এর ফর্মুলা
কখনই অনুমানের ওপর লট সাইজ নির্ধারণ করবেন না।
১. ডলার রিস্ক হিসেব করুন: $৫,০০০ একাউন্টে ১% রিস্ক = **$৫০ ডলার**।
২. চার্টে স্টপ লস মাপুন: ধরুন ২৫ পিপ।
৩. লট সাইজ = $৫০ / (২৫ × $১০) = **০.২০ লট**।`,
    keyTakeawaysEn: [
      'Limit risk to 1% to 2% maximum on any single idea.',
      'Your stop loss dictates your lot size, not the other way around.',
      'Risk management is the only holy grail in financial markets.'
    ],
    keyTakeawaysBn: [
      'যেকোনো একক ট্রেডে সর্বোচ্চ ১% থেকে ২% ঝুঁকি রাখুন।',
      'স্টপ লসের দূরত্ব অনুযায়ী লট সাইজ হিসেব হবে, মনগড়া নয়।',
      'রিস্ক ম্যানেজমেন্টই ফরেক্স মার্কেটে টিকে থাকার মূল চাবিকাঠি।'
    ],
    quiz: [
      {
        id: 'q-41-1',
        questionEn: 'On a $10,000 account, what is the maximum recommended risk at 1%?',
        questionBn: '$১০,০০০ ডলার অ্যাকাউন্টে ১% নিয়মে সর্বোচ্চ রিস্ক কত ডলার?',
        optionsEn: ['$10', '$100', '$1,000', '$500'],
        optionsBn: ['$১০', '$১০০', '$১,০০০', '$৫০০'],
        correctAnswer: 1,
        explanationEn: '1% of $10,000 is $100.',
        explanationBn: '$১০,০০০ এর ১% হলো $১০০ ডলার।'
      }
    ],
    isPublished: true,
    createdAt: '2026-01-14T10:00:00Z',
  }
];

const INITIAL_TUTORIALS: Tutorial[] = [
  {
    id: 'tut-exness-setup',
    titleEn: 'Step-by-Step Exness Account Setup & Identity Verification',
    titleBn: 'ধাপে ধাপে এক্সনেস (Exness) অ্যাকাউন্ট খোলা ও ভেরিফিকেশন গাইড',
    category: 'exness',
    readTime: '8 min read',
    steps: [
      {
        titleEn: 'Step 1: Registration with Real Credentials',
        titleBn: 'ধাপ ১: সঠিক তথ্য দিয়ে রেজিস্ট্রেশন',
        descriptionEn: 'Visit the official broker portal. Register using a valid personal email address and strong password containing letters, numbers, and special symbols.',
        descriptionBn: 'অফিসিয়াল ব্রোকার পোর্টালে যান। সঠিক ইমেইল ও শক্তিশালী পাসওয়ার্ড দিয়ে একাউন্ট তৈরি করুন।',
        tipEn: 'Ensure your name matches your government ID exactly.',
        tipBn: 'নামটি আপনার জাতীয় পরিচয়পত্র বা পাসপোর্টের সাথে হুবহু মিলিয়ে লিখুন।'
      },
      {
        titleEn: 'Step 2: Proof of Identity (POI) Verification',
        titleBn: 'ধাপ ২: জাতীয় পরিচয়পত্র (POI) সাবমিট',
        descriptionEn: 'Upload clear color photographs of your Passport, National ID card, or Driving License. All 4 corners must be visible with zero glare.',
        descriptionBn: 'পাসপোর্ট বা স্মার্ট এনআইডি কার্ডের দুই পাশের পরিষ্কার রঙিন ছবি আপলোড করুন। চার কোণা যেন সুস্পষ্ট থাকে।',
      },
      {
        titleEn: 'Step 3: Proof of Residence (POR) Verification',
        titleBn: 'ধাপ ৩: ঠিকানার প্রমাণপত্র (POR) সাবমিট',
        descriptionEn: 'Submit a recent utility bill or bank statement (issued within the last 90 days) showing your full name and residential address.',
        descriptionBn: 'গত ৩ মাসের ব্যাংক স্টেটমেন্ট বা ইউটিলিটি বিল আপলোড করুন যেখানে নাম ও ঠিকানা পরিষ্কার দেখা যায়।',
      },
      {
        titleEn: 'Step 4: Creating MT4/MT5 Real & Demo Accounts',
        titleBn: 'ধাপ ৪: MT4/MT5 রিয়েল ও ডেমো অ্যাকাউন্ট তৈরি',
        descriptionEn: 'Select Raw Spread or Standard account type. Set leverage (1:100 or 1:200 recommended for beginners), currency USD, and create your trading terminal password.',
        descriptionBn: 'স্ট্যান্ডার্ড বা র স্প্রেড একাউন্ট নির্বাচন করুন। লিভারেজ ১:১০০ রাখুন এবং ট্রেডিং টার্মিনাল পাসওয়ার্ড সেট করুন।',
      }
    ],
    isPublished: true,
  },
  {
    id: 'tut-tradingview',
    titleEn: 'TradingView Charting Mastery: Tools, Indicators & Templates',
    titleBn: 'ট্রেডিংভিউ (TradingView) চার্ট ব্যবহারের পূর্ণাঙ্গ নির্দেশিকা',
    category: 'tradingview',
    readTime: '10 min read',
    steps: [
      {
        titleEn: 'Step 1: Workspace & Chart Clean Up',
        titleBn: 'ধাপ ১: চার্ট ওয়ার্কস্পেস সেটআপ',
        descriptionEn: 'Open TradingView, select your desired pair (e.g. FX:EURUSD). Remove distracting default volume bars and set a clean dark background for high legibility.',
        descriptionBn: 'ট্রেডিংভিউতে কাঙ্ক্ষিত পেয়ার সিলেক্ট করুন এবং অতিরিক্ত অনাবশ্যক ইন্ডিকেটর সরিয়ে পরিষ্কার চার্ট রাখুন।',
      },
      {
        titleEn: 'Step 2: Key Drawing Tools (Horizontal Rays & Fib)',
        titleBn: 'ধাপ ২: ড্রয়িং টুলস ব্যবহার (সাপোর্ট ও ফিবোনাচি)',
        descriptionEn: 'Use the Horizontal Line (Alt+H) to mark key Daily and 4H support/resistance levels. Use the Long/Short Position tool to visualize Risk-to-Reward before taking any trade.',
        descriptionBn: 'হরিজন্টাল লাইন দিয়ে মূল সাপোর্ট-রেজিস্ট্যান্স চিহ্নিত করুন এবং ট্রেড নেওয়ার পূর্বে লং/শর্ট টুল দিয়ে রিস্ক-রিওয়ার্ড পরিমাপ করুন।',
      },
      {
        titleEn: 'Step 3: Multi-Timeframe Alignment',
        titleBn: 'ধাপ ৩: মাল্টি-টাইমফ্রেম বিশ্লেষণ',
        descriptionEn: 'Always check the higher timeframe (Daily/4H) for macro trend direction, then drop down to 1H or 15m to time precise entries with lower risk.',
        descriptionBn: 'বড় টাইমফ্রেমে (Daily/4H) মূল ট্রেন্ড দেখুন এবং ছোট টাইমফ্রেমে (15m) নির্ভুল এন্ট্রি গ্রহণ করুন।',
      }
    ],
    isPublished: true,
  },
  {
    id: 'tut-security',
    titleEn: 'Forex Account Security, 2FA, and Phishing Protection',
    titleBn: 'ট্রেডিং অ্যাকাউন্ট নিরাপত্তা ও টু-ফ্যাক্টর অথেনটিকেশন (2FA)',
    category: 'security',
    readTime: '6 min read',
    steps: [
      {
        titleEn: 'Step 1: Enable Authenticator App (2FA)',
        titleBn: 'ধাপ ১: গুগল অথেনটিকেটর (2FA) চালু করা',
        descriptionEn: 'Never rely on SMS verification alone. Enable Google Authenticator or hardware security keys on your broker and email accounts.',
        descriptionBn: 'শুধুমাত্র এসএমএস কোডের উপর নির্ভর না করে গুগল অথেনটিকেটর অ্যাপ সক্রিয় করুন।',
      },
      {
        titleEn: 'Step 2: Guard Against Impersonators & Telegram Scammers',
        titleBn: 'ধাপ ২: ভুয়া সিগন্যাল গ্রুপ ও টেলিগ্রাম স্ক্যামার থেকে সতর্কতা',
        descriptionEn: 'Real brokers never message you on WhatsApp or Telegram asking for account credentials or offering guaranteed returns. Always double-check domain URLs.',
        descriptionBn: 'কোনো বৈধ ব্রোকার টেলিগ্রামে মেসেজ দিয়ে পাসওয়ার্ড চাইবে না কিংবা নিশ্চিত আয়ের লোভ দেখাবে না। ভুয়া লিঙ্ক এড়িয়ে চলুন।',
      }
    ],
    isPublished: true,
  }
];

const INITIAL_RESOURCES: ResourceItem[] = [
  {
    id: 'res-candlestick-cheat',
    titleEn: 'High-Probability Candlestick Cheat Sheet',
    titleBn: 'উচ্চ সাফল্যের ক্যান্ডেলস্টিক চিট শিট',
    category: 'cheatsheet',
    format: 'Guide',
    descriptionEn: 'Visual reference guide covering pin bars, engulfing candles, inside bars, morning/evening stars, and exhaustion wicks.',
    descriptionBn: 'পিন বার, এনগালফিং, মর্নিং স্টার এবং উইক রিজেকশন প্যাটার্নের বিস্তারিত নির্দেশিকা।',
    contentEn: `### Essential Patterns:
1. **Bullish Pin Bar / Hammer**: Strong rejection of support zone with lower wick 2x body length.
2. **Bearish Shooting Star**: Rejection at resistance with upper wick 2x body length.
3. **Bullish Engulfing**: Complete body overlap confirming buyer commitment.
4. **Bearish Engulfing**: Complete body overlap confirming aggressive selling.
5. **Inside Bar**: Consolidation bar fully within previous candle's high and low, signaling breakout potential.`,
    contentBn: `### গুরুত্বপূর্ণ প্যাটার্নসমূহ:
১. **বুলিশ পিন বার (Hammer)**: সাপোর্ট এলাকায় নিচের লম্বা উইক যা ক্রয়ের শক্তির পরিচয় দেয়।
২. **বিয়ারিশ শুটিং স্টার**: রেজিস্ট্যান্সে উপরের লম্বা উইক যা বিক্রেতাদের প্রত্যাখান নির্দেশ করে।
৩. **বুলিশ এনগালফিং**: পূর্ববর্তী ক্যান্ডেলকে সম্পূর্ণরূপে গ্রাসকারী বড় সবুজ ক্যান্ডেল।
৪. **ইনসাইড বার**: পূর্ববর্তী ক্যান্ডেলের সীমার মধ্যে থাকা ছোট ক্যান্ডেল, যা ব্রেকআউটের পূর্বলক্ষণ।`,
  },
  {
    id: 'res-pre-trade-checklist',
    titleEn: '20-Point Pre-Trade Execution Checklist',
    titleBn: 'ট্রেড নেওয়ার আগের ২০-পয়েন্ট চেকলিস্ট',
    category: 'checklist',
    format: 'Interactive',
    descriptionEn: 'Never execute a trade on emotional impulse. Walk through this verified pre-flight checklist.',
    descriptionBn: 'আবেগের বশে ট্রেড না নিয়ে এই যাচাইকৃত চেকলিস্ট মিলিয়ে তারপর এন্ট্রি নিন।',
    contentEn: `### Pre-Flight Checklist:
1. Higher Timeframe Trend identified (Daily & 4H).
2. Key Support / Resistance zone marked.
3. No high-impact red-folder economic news within 30 minutes.
4. Clear price action signal formed (pin bar, breakout retest).
5. Stop Loss placed at technical invalidation level (not arbitrary dollar amount).
6. Risk calculated and strictly <= 1% of account equity.
7. Minimum 1:2 Risk-to-Reward ratio available to logical target.
8. Mentally prepared to accept the stop loss if trade fails.`,
    contentBn: `### ট্রেড এক্সিকিউশন চেকলিস্ট:
১. বড় টাইমফ্রেমে (Daily/4H) মূল ট্রেন্ড নিশ্চিত করা হয়েছে কি?
২. স্পষ্ট সাপোর্ট বা রেজিস্ট্যান্স এলাকা চিহ্নিত আছে কি?
৩. আগামী ৩০ মিনিটে উচ্চ ঝুঁকিপূর্ণ কোনো রেড ফোল্ডার নিউজ আছে কি?
৪. স্পষ্ট প্রাইস অ্যাকশন সিগন্যাল (যেমন পিন বার বা রিটেস্ট) তৈরি হয়েছে কি?
৫. স্টপ লস টেকনিক্যাল লেভেলের বাইরে সেট করা হয়েছে কি?
৬. ঝুঁকি কি ব্যালেন্সের ১% এর সমান বা কম?
৭. ন্যূনতম ১:২ রিস্ক-টু-রিওয়ার্ড রেশিও বিদ্যমান কি?
৮. লস হলেও শান্ত থাকার মানসিক প্রস্তুতি আছে কি?`,
  },
  {
    id: 'res-forex-glossary',
    titleEn: 'Forex Master Glossary (A-Z Terms)',
    titleBn: 'ফরেক্স সম্পূর্ণ পরিভাষা ও শব্দকোষ (A-Z)',
    category: 'glossary',
    format: 'Guide',
    descriptionEn: 'Comprehensive dictionary explaining 40+ vital trading terms in plain English and Bangla.',
    descriptionBn: '৪০টিরও বেশি গুরুত্বপূর্ণ ফরেক্স শব্দের সহজ ও প্রাতিষ্ঠানিক ব্যাখ্যা।',
    contentEn: `### Key Definitions:
- **Bear Market**: Market characterized by falling prices and seller dominance.
- **Bull Market**: Market characterized by rising prices and buyer dominance.
- **Drawdown**: The percentage decline from a trading account's peak equity to its trough.
- **ECN (Electronic Communication Network)**: Broker model routing client orders directly to interbank liquidity providers with no dealing desk interference.
- **Liquidity**: The degree to which an asset can be quickly bought or sold without causing a significant price change.
- **Slippage**: Difference between expected execution price and actual filled price during fast markets.
- **Swap / Rollover**: Overnight interest paid or earned for holding a currency position past 5 PM New York time.`,
    contentBn: `### প্রয়োজনীয় পরিভাষাসমূহ:
- **বুল মার্কেট (Bull Market)**: যখন বাজারে দাম ক্রমাগত বাড়তে থাকে এবং ক্রেতারা সক্রিয় থাকে।
- **বিয়ার মার্কেট (Bear Market)**: যখন বাজারে দাম কমতে থাকে এবং বিক্রেতারা প্রাধান্য বিস্তার করে।
- **ড্রডাউন (Drawdown)**: অ্যাকাউন্টের সর্বোচ্চ ব্যালেন্স থেকে বর্তমান লসের শতকরা হার।
- **লিকুইডিটি (Liquidity)**: বাজারে সহজে এবং দ্রুত কেনাবেচা করার মতো তারল্য বা সক্রিয় অংশগ্রহণকারীর সংখ্যা।
- **স্লিপেজ (Slippage)**: নিউজ বা দ্রুত মুভমেন্টের সময় প্রত্যাশিত দামের চেয়ে ভিন্ন দামে ট্রেড ওপেন হওয়ার ঘটনা।
- **সোয়াপ (Swap)**: রাতভর ট্রেড খোলা রাখার জন্য প্রযোজ্য সুদ বা ব্রোকার চার্জ (ইসলামিক অ্যাকাউন্টে সোয়াপ-ফ্রি থাকে)।`,
  }
];

const INITIAL_EVENTS: EconomicEvent[] = [
  {
    id: 'ev-1',
    time: '12:30 UTC',
    currency: 'USD',
    eventEn: 'Core Consumer Price Index (CPI) m/m',
    eventBn: 'কোর কনজিউমার প্রাইজ ইনডেক্স (CPI)',
    impact: 'HIGH',
    actual: '0.3%',
    forecast: '0.3%',
    previous: '0.2%',
    descriptionEn: 'Measures change in goods/services prices excluding volatile food and energy. Critical benchmark for Federal Reserve interest rate policy.',
    descriptionBn: 'যুক্তরাষ্ট্রের মূল্যস্ফীতির প্রধান পরিমাপক। ফেড সুদের হার পরিবর্তনের সিদ্ধান্তে এর ওপর নির্ভর করে।'
  },
  {
    id: 'ev-2',
    time: '13:15 UTC',
    currency: 'EUR',
    eventEn: 'ECB Main Refinancing Rate Decision',
    eventBn: 'ইউরোপীয় সেন্ট্রাল ব্যাংক (ECB) সুদের হার সিদ্ধান্ত',
    impact: 'HIGH',
    actual: '3.65%',
    forecast: '3.65%',
    previous: '3.75%',
    descriptionEn: 'European Central Bank interest rate announcement impacting Euro strength across all EUR pairs.',
    descriptionBn: 'ইউরোপের সুদের হারের সিদ্ধান্ত যা সকল ইউরো পেয়ারকে গভীরভাবে প্রভাবিত করে।'
  },
  {
    id: 'ev-3',
    time: '12:30 UTC',
    currency: 'USD',
    eventEn: 'Non-Farm Payrolls (NFP) Employment Change',
    eventBn: 'নন-ফার্ম পে-রোল (NFP) কর্মসংস্থান ডাটা',
    impact: 'HIGH',
    actual: '175K',
    forecast: '160K',
    previous: '142K',
    descriptionEn: 'Change in the number of employed people in the US non-farm business sector. Major driver of short-term USD volatility.',
    descriptionBn: 'যুক্তরাষ্ট্রের শ্রমবাজারের সবচেয়ে গুরুত্বপূর্ণ ডাটা যা প্রকাশের সময় বাজারে তীব্র ওঠানামা তৈরি হয়।'
  },
  {
    id: 'ev-4',
    time: '07:00 UTC',
    currency: 'GBP',
    eventEn: 'UK Gross Domestic Product (GDP) m/m',
    eventBn: 'যুক্তরাজ্য জিডিপি (GDP) প্রবৃদ্ধি',
    impact: 'MEDIUM',
    actual: '0.2%',
    forecast: '0.1%',
    previous: '0.0%',
    descriptionEn: 'Broadest measure of UK economic activity and the primary gauge of the economy’s health.',
    descriptionBn: 'যুক্তরাজ্যের অর্থনৈতিক উৎপাদন ও প্রবৃদ্ধির সার্বিক সূচক।'
  },
  {
    id: 'ev-5',
    time: '03:30 UTC',
    currency: 'AUD',
    eventEn: 'RBA Interest Rate Statement',
    eventBn: 'অস্ট্রেলিয়ান রিজার্ভ ব্যাংক (RBA) সুদের হার পলিসি',
    impact: 'HIGH',
    actual: '4.35%',
    forecast: '4.35%',
    previous: '4.35%',
    descriptionEn: 'Reserve Bank of Australia’s monetary policy decision impacting Australian Dollar volatility.',
    descriptionBn: 'অস্ট্রেলিয়ার সেন্ট্রাল ব্যাংকের পলিসি স্টেটমেন্ট যা অসি ডলারের মান নির্ধারণে ভূমিকা রাখে।'
  }
];

const INITIAL_ANNOUNCEMENTS: PlatformAnnouncement[] = [
  {
    id: 'ann-1',
    titleEn: 'Smart Forex Hub v2.0 Live: High-Precision Calculators & AI Assistant',
    titleBn: 'স্মার্ট ফরেক্স হাব ২.০ চালু হয়েছে: আধুনিক ক্যালকুলেটর ও এআই সহকারী',
    messageEn: 'Welcome to Smart Forex Hub! Explore complete bilingual Forex courses, risk calculators, our private journal, and interactive AI mentoring.',
    messageBn: 'স্মার্ট ফরেক্স হাবে স্বাগতম! বাংলা ও ইংরেজিতে পূর্ণাঙ্গ ফরেক্স কোর্স, রিস্ক ক্যালকুলেটর, ব্যক্তিগত জার্নাল এবং এআই মেন্টর ব্যবহার করুন।',
    type: 'success',
    active: true,
    createdAt: '2026-02-01T08:00:00Z'
  }
];

const INITIAL_COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: 'post-1',
    userId: 'user-admin',
    userName: 'Hub Chief Educator',
    userRole: 'admin',
    title: 'Why 1:2 Risk-to-Reward beats a 70% win-rate strategy over 100 trades',
    content: 'Many beginner traders obsess over having an 80% or 90% win rate. In reality, a trader with just a 40% win rate using a disciplined 1:2 R:R ratio will be comfortably profitable, whereas a 90% win rate trader with no stop loss will blow their account in a single flash crash.',
    category: 'strategy',
    likesCount: 14,
    commentsCount: 2,
    isReported: false,
    status: 'approved',
    createdAt: '2026-02-10T12:00:00Z',
    comments: [
      {
        id: 'comm-1',
        postId: 'post-1',
        userId: 'trader-1',
        userName: 'Tanvir Ahmed',
        userRole: 'trader',
        content: 'This completely changed my perspective! I used to cut winning trades at +5 pips and let losers run -60 pips.',
        createdAt: '2026-02-10T14:30:00Z'
      }
    ]
  },
  {
    id: 'post-2',
    userId: 'trader-2',
    userName: 'Sabbir Hossain',
    userRole: 'trader',
    title: 'Exness document verification rejected - what was the issue?',
    content: 'My bank statement was initially rejected because I submitted an electronic screenshot. After downloading the official signed e-statement PDF from my bank app, it was approved within 15 minutes!',
    category: 'brokers',
    likesCount: 8,
    commentsCount: 1,
    isReported: false,
    status: 'approved',
    createdAt: '2026-02-12T09:15:00Z',
    comments: [
      {
        id: 'comm-2',
        postId: 'post-2',
        userId: 'user-admin',
        userName: 'Hub Chief Educator',
        userRole: 'admin',
        content: 'Great reminder! The proof of residence must always have full address and bank logo visible without crops.',
        createdAt: '2026-02-12T10:00:00Z'
      }
    ]
  }
];

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.warn('Failed to read db.json, initializing fresh store:', e);
    }

    const defaultAdmin: User & { passwordHash: string } = {
      id: 'admin-master',
      name: 'System Administrator',
      email: 'admin@smartforexhub.com',
      role: 'admin',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      createdAt: new Date().toISOString(),
      passwordHash: hashPassword('Admin@ForexHub2026'),
    };

    const initialData: DatabaseSchema = {
      users: [defaultAdmin],
      courses: INITIAL_COURSES,
      lessons: INITIAL_LESSONS,
      tutorials: INITIAL_TUTORIALS,
      resources: INITIAL_RESOURCES,
      trades: [],
      events: INITIAL_EVENTS,
      communityPosts: INITIAL_COMMUNITY_POSTS,
      comments: [
        {
          id: 'comm-1',
          postId: 'post-1',
          userId: 'trader-1',
          userName: 'Tanvir Ahmed',
          userRole: 'trader',
          content: 'This completely changed my perspective! I used to cut winning trades at +5 pips and let losers run -60 pips.',
          createdAt: '2026-02-10T14:30:00Z'
        }
      ],
      announcements: INITIAL_ANNOUNCEMENTS
    };

    this.saveData(initialData);
    return initialData;
  }

  private saveData(data: DatabaseSchema): void {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error saving db.json:', e);
    }
  }

  public save(): void {
    this.saveData(this.data);
  }

  public getRaw(): DatabaseSchema {
    return this.data;
  }

  // User management
  public findUserByEmail(email: string) {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string) {
    const user = this.data.users.find(u => u.id === id);
    if (!user) return null;
    const { passwordHash: _, ...safe } = user;
    return safe;
  }

  public createUser(name: string, email: string, passwordPlain: string, role: 'admin' | 'trader' = 'trader') {
    const newUser: User & { passwordHash: string } = {
      id: 'usr_' + crypto.randomUUID().slice(0, 8),
      name,
      email: email.toLowerCase(),
      role,
      avatar: `https://api.dicebear.com/7.x/identicon/svg?seed=${encodeURIComponent(email)}`,
      createdAt: new Date().toISOString(),
      passwordHash: hashPassword(passwordPlain)
    };
    this.data.users.push(newUser);
    this.save();
    const { passwordHash: _, ...safe } = newUser;
    return safe;
  }

  // Course / Lesson methods
  public getCourses() {
    return this.data.courses;
  }

  public getLessons(courseId?: string) {
    if (courseId) {
      return this.data.lessons.filter(l => l.courseId === courseId);
    }
    return this.data.lessons;
  }

  public getLessonById(id: string) {
    return this.data.lessons.find(l => l.id === id || l.slug === id);
  }

  public upsertLesson(lesson: Lesson) {
    const index = this.data.lessons.findIndex(l => l.id === lesson.id);
    if (index >= 0) {
      this.data.lessons[index] = { ...this.data.lessons[index], ...lesson };
    } else {
      this.data.lessons.push(lesson);
    }
    this.save();
    return lesson;
  }

  public deleteLesson(id: string) {
    this.data.lessons = this.data.lessons.filter(l => l.id !== id);
    this.save();
  }

  // Trade Journal methods (User-scoped)
  public getTradesForUser(userId: string) {
    return this.data.trades
      .filter(t => t.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  public addTrade(trade: Omit<TradeRecord, 'id' | 'createdAt'>) {
    const newTrade: TradeRecord = {
      ...trade,
      id: 'trade_' + crypto.randomUUID().slice(0, 8),
      createdAt: new Date().toISOString()
    };
    this.data.trades.push(newTrade);
    this.save();
    return newTrade;
  }

  public updateTrade(id: string, userId: string, updates: Partial<TradeRecord>) {
    const index = this.data.trades.findIndex(t => t.id === id && t.userId === userId);
    if (index === -1) return null;
    this.data.trades[index] = { ...this.data.trades[index], ...updates };
    this.save();
    return this.data.trades[index];
  }

  public deleteTrade(id: string, userId: string) {
    const prevLen = this.data.trades.length;
    this.data.trades = this.data.trades.filter(t => !(t.id === id && t.userId === userId));
    this.save();
    return this.data.trades.length < prevLen;
  }

  // Community methods
  public getCommunityPosts() {
    return this.data.communityPosts.filter(p => p.status === 'approved' || p.status === 'pending');
  }

  public addCommunityPost(post: Omit<CommunityPost, 'id' | 'likesCount' | 'commentsCount' | 'isReported' | 'status' | 'createdAt'>) {
    const newPost: CommunityPost = {
      ...post,
      id: 'post_' + crypto.randomUUID().slice(0, 8),
      likesCount: 0,
      commentsCount: 0,
      isReported: false,
      status: 'approved',
      createdAt: new Date().toISOString(),
      comments: []
    };
    this.data.communityPosts.unshift(newPost);
    this.save();
    return newPost;
  }

  public reportPost(postId: string) {
    const post = this.data.communityPosts.find(p => p.id === postId);
    if (post) {
      post.isReported = true;
      this.save();
      return true;
    }
    return false;
  }

  public moderatePost(postId: string, status: 'approved' | 'rejected', deleteItem = false) {
    if (deleteItem) {
      this.data.communityPosts = this.data.communityPosts.filter(p => p.id !== postId);
    } else {
      const post = this.data.communityPosts.find(p => p.id === postId);
      if (post) {
        post.status = status;
        if (status === 'approved') post.isReported = false;
      }
    }
    this.save();
    return true;
  }

  public addComment(postId: string, userId: string, userName: string, userRole: 'admin' | 'trader', content: string) {
    const comment: CommunityComment = {
      id: 'comm_' + crypto.randomUUID().slice(0, 8),
      postId,
      userId,
      userName,
      userRole,
      content,
      createdAt: new Date().toISOString()
    };
    this.data.comments.push(comment);
    const post = this.data.communityPosts.find(p => p.id === postId);
    if (post) {
      if (!post.comments) post.comments = [];
      post.comments.push(comment);
      post.commentsCount = post.comments.length;
    }
    this.save();
    return comment;
  }
}

export const db = new Database();
