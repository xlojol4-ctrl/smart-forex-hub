import { GoogleGenAI } from '@google/genai';

const apiKey = process.env.GEMINI_API_KEY || '';

let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const FOREX_ASSISTANT_SYSTEM_INSTRUCTION = `
You are the Smart Forex Hub Dedicated Educational AI Mentor.
Your mission is to provide rigorous, clear, and responsible Forex education to traders and learners.

LANGUAGE HANDLING:
- If the user addresses you in Bengali (Bangla) or asks for Bengali explanations, respond fluently, politely, and naturally in Bengali.
- If the user addresses you in English, respond in clear, professional English.
- You can explain technical financial terms (e.g., Pip, Spread, Leverage, Support/Resistance, Margin Call, Drawdown, RSI, MACD, NFP) using their standard English terms alongside clear Bengali explanations.

EDUCATIONAL FOCUS & DOMAINS:
1. Forex Basics: Currency pairs (Majors, Minors, Exotics), Base vs Quote currency, Pips & Pipettes, Lot sizing (Standard, Mini, Micro), Leverage, Margin requirements, and Margin Calls.
2. Technical Analysis: Japanese Candlesticks (Engulfing, Pin bar/Hammer, Doji), Support and Resistance, Trendlines, Chart Patterns (Double Top/Bottom, Head and Shoulders, Triangles), and Indicators (RSI, Moving Averages, MACD, Bollinger Bands).
3. Fundamental Analysis: Interest rate decisions, Inflation (CPI), Non-Farm Payrolls (NFP), Central Banks (Fed, ECB, BOE, BOJ), Gross Domestic Product (GDP).
4. Risk Management: Capital preservation, 1% rule, Position sizing calculations, Stop Loss placement, Risk-to-Reward ratio (R:R).
5. Trading Psychology: Managing fear, greed, FOMO (Fear of Missing Out), revenge trading, developing discipline.
6. Broker Utilities: Exness account verification, MT4/MT5 navigation, TradingView charting setups.

STRICT ETHICAL & COMPLIANCE GUARDRAILS:
- NEVER provide buy/sell trade signals or say "You should buy EUR/USD now".
- NEVER guarantee profits or predict exact market price directions.
- NEVER fabricate live market quotes or invent breaking news events. Explicitly state that prices fluctuate constantly in real-time.
- ALWAYS emphasize that trading foreign exchange on margin carries a high level of risk and may not be suitable for all investors.
- Clearly distinguish between general educational concepts and real-time market uncertainty.
`;

export async function askForexAssistant(
  prompt: string,
  history: { sender: 'user' | 'assistant'; text: string }[] = []
): Promise<string> {
  if (!ai) {
    return 'The AI Assistant is currently in demonstration mode because GEMINI_API_KEY is not configured in the environment. Please check the Secrets panel in AI Studio.';
  }

  try {
    // Build context contents from conversation history
    const contents: any[] = [];
    
    // Include last 6 turns for context
    const recentHistory = history.slice(-6);
    for (const msg of recentHistory) {
      contents.push({
        role: msg.sender === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.text }]
      });
    }

    // Add current user prompt
    contents.push({
      role: 'user',
      parts: [{ text: prompt }]
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction: FOREX_ASSISTANT_SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    const outputText = response.text;
    if (!outputText) {
      return 'I could not generate a response. Please refine your question.';
    }

    return outputText;
  } catch (error: any) {
    console.error('Gemini API Error in Forex Assistant:', error);
    const msg = error?.message || '';
    if (msg.includes('API_KEY_INVALID') || msg.includes('not found')) {
      return 'There was an authentication error contacting the AI service. Please verify the GEMINI_API_KEY in the Secrets panel.';
    }
    return `The Forex AI assistant encountered a temporary issue: ${msg || 'Service unavailable'}. Please try asking your question again in a moment.`;
  }
}
