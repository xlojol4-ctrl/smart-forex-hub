import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'node:crypto';
import { db, verifyPassword } from './server/db.ts';
import { askForexAssistant } from './server/gemini.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json());

// Token session cache: token -> { userId, expiresAt }
const sessions = new Map<string, { userId: string; expiresAt: number }>();

function generateToken(userId: string): string {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, {
    userId,
    expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 // 7 days
  });
  return token;
}

// Auth Middleware
function authenticateUser(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];
  const session = sessions.get(token);

  if (!session || session.expiresAt < Date.now()) {
    sessions.delete(token);
    return res.status(401).json({ error: 'Session expired or invalid' });
  }

  const user = db.findUserById(session.userId);
  if (!user) {
    return res.status(401).json({ error: 'User no longer exists' });
  }

  (req as any).user = user;
  next();
}

// Optional Auth (for community views that can identify the user if present)
function optionalAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const session = sessions.get(token);
    if (session && session.expiresAt >= Date.now()) {
      const user = db.findUserById(session.userId);
      if (user) {
        (req as any).user = user;
      }
    }
  }
  next();
}

// Admin Middleware
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user;
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden: Administrator privileges required' });
  }
  next();
}

// ==================== AUTH API ====================

app.post('/api/auth/register', (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }

    const newUser = db.createUser(name, email, password, 'trader');
    const token = generateToken(newUser.id);
    res.status(201).json({ user: newUser, token });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const user = db.findUserByEmail(email);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = generateToken(user.id);
    const { passwordHash: _, ...safeUser } = user;
    res.json({ user: safeUser, token });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Login failed' });
  }
});

app.get('/api/auth/me', authenticateUser, (req: Request, res: Response) => {
  res.json({ user: (req as any).user });
});

// ==================== COURSES & LESSONS API ====================

app.get('/api/courses', (_req: Request, res: Response) => {
  const courses = db.getCourses();
  res.json({ courses });
});

app.get('/api/lessons', (req: Request, res: Response) => {
  const courseId = req.query.courseId as string | undefined;
  const lessons = db.getLessons(courseId);
  res.json({ lessons });
});

app.get('/api/lessons/:id', (req: Request, res: Response) => {
  const lesson = db.getLessonById(req.params.id);
  if (!lesson) {
    return res.status(404).json({ error: 'Lesson not found' });
  }
  res.json({ lesson });
});

app.post('/api/admin/lessons', authenticateUser, requireAdmin, (req: Request, res: Response) => {
  try {
    const newLesson = {
      ...req.body,
      id: req.body.id || 'les_' + crypto.randomUUID().slice(0, 8),
      createdAt: new Date().toISOString()
    };
    db.upsertLesson(newLesson);
    res.status(201).json({ lesson: newLesson });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/lessons/:id', authenticateUser, requireAdmin, (req: Request, res: Response) => {
  try {
    const updated = db.upsertLesson({ ...req.body, id: req.params.id });
    res.json({ lesson: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/admin/lessons/:id', authenticateUser, requireAdmin, (req: Request, res: Response) => {
  try {
    db.deleteLesson(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== TUTORIALS & RESOURCES API ====================

app.get('/api/tutorials', (_req: Request, res: Response) => {
  res.json({ tutorials: db.getRaw().tutorials });
});

app.get('/api/resources', (_req: Request, res: Response) => {
  res.json({ resources: db.getRaw().resources });
});

// ==================== TRADING JOURNAL API (USER-SCOPED) ====================

app.get('/api/journal', authenticateUser, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const trades = db.getTradesForUser(userId);
  res.json({ trades });
});

app.post('/api/journal', authenticateUser, (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const { date, pair, type, lotSize, entryPrice, stopLoss, takeProfit, exitPrice, status, pnl, pips, strategy, emotion, notes } = req.body;

    if (!pair || !type || !entryPrice || !lotSize) {
      return res.status(400).json({ error: 'Pair, type, entry price, and lot size are required' });
    }

    const trade = db.addTrade({
      userId,
      date: date || new Date().toISOString().split('T')[0],
      pair: pair.toUpperCase(),
      type,
      lotSize: Number(lotSize),
      entryPrice: Number(entryPrice),
      stopLoss: Number(stopLoss) || 0,
      takeProfit: Number(takeProfit) || 0,
      exitPrice: exitPrice ? Number(exitPrice) : undefined,
      status: status || 'OPEN',
      pnl: pnl !== undefined ? Number(pnl) : undefined,
      pips: pips !== undefined ? Number(pips) : undefined,
      strategy: strategy || 'Discretionary',
      emotion: emotion || 'Disciplined',
      notes: notes || ''
    });

    res.status(201).json({ trade });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/journal/:id', authenticateUser, (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const updated = db.updateTrade(req.params.id, userId, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Trade not found or access denied' });
    }
    res.json({ trade: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/journal/:id', authenticateUser, (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const success = db.deleteTrade(req.params.id, userId);
    if (!success) {
      return res.status(404).json({ error: 'Trade not found' });
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/journal/stats', authenticateUser, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const trades = db.getTradesForUser(userId);

  const totalTrades = trades.length;
  const closedTrades = trades.filter(t => t.status !== 'OPEN');
  const wins = closedTrades.filter(t => t.status === 'WIN');
  const losses = closedTrades.filter(t => t.status === 'LOSS');
  const winRate = closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0;

  const totalProfit = wins.reduce((acc, t) => acc + (t.pnl || 0), 0);
  const totalLoss = Math.abs(losses.reduce((acc, t) => acc + (t.pnl || 0), 0));
  const netPnL = trades.reduce((acc, t) => acc + (t.pnl || 0), 0);
  const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? totalProfit : 0;

  res.json({
    totalTrades,
    closedTradesCount: closedTrades.length,
    winsCount: wins.length,
    lossesCount: losses.length,
    winRate: Number(winRate.toFixed(1)),
    netPnL: Number(netPnL.toFixed(2)),
    totalProfit: Number(totalProfit.toFixed(2)),
    totalLoss: Number(totalLoss.toFixed(2)),
    profitFactor: Number(profitFactor.toFixed(2)),
  });
});

// ==================== ECONOMIC CALENDAR API ====================

app.get('/api/calendar', (_req: Request, res: Response) => {
  res.json({ events: db.getRaw().events });
});

// ==================== COMMUNITY API ====================

app.get('/api/community/posts', optionalAuth, (_req: Request, res: Response) => {
  const posts = db.getCommunityPosts();
  res.json({ posts });
});

app.post('/api/community/posts', authenticateUser, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { title, content, category } = req.body;

    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }

    const post = db.addCommunityPost({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      title,
      content,
      category: category || 'beginner'
    });

    res.status(201).json({ post });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/community/posts/:id/comments', authenticateUser, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ error: 'Comment content is required' });
    }

    const comment = db.addComment(req.params.id, user.id, user.name, user.role, content);
    res.status(201).json({ comment });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/community/posts/:id/report', authenticateUser, (req: Request, res: Response) => {
  const success = db.reportPost(req.params.id);
  res.json({ success });
});

app.post('/api/admin/community/:id/moderate', authenticateUser, requireAdmin, (req: Request, res: Response) => {
  const { status, deleteItem } = req.body;
  const success = db.moderatePost(req.params.id, status, !!deleteItem);
  res.json({ success });
});

// ==================== ANNOUNCEMENTS API ====================

app.get('/api/announcements', (_req: Request, res: Response) => {
  const active = db.getRaw().announcements.filter(a => a.active);
  res.json({ announcements: active });
});

// ==================== FOREX AI ASSISTANT API ====================

app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { prompt, history } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'A question or prompt is required' });
    }

    const answer = await askForexAssistant(prompt, Array.isArray(history) ? history : []);
    res.json({ response: answer });
  } catch (err: any) {
    console.error('Error in /api/ai/chat:', err);
    res.status(500).json({ error: err.message || 'AI processing error' });
  }
});

// ==================== ADMIN METRICS & DATA ====================

app.get('/api/admin/metrics', authenticateUser, requireAdmin, (_req: Request, res: Response) => {
  const raw = db.getRaw();
  res.json({
    totalUsers: raw.users.length,
    totalCourses: raw.courses.length,
    totalLessons: raw.lessons.length,
    totalPosts: raw.communityPosts.length,
    reportedPostsCount: raw.communityPosts.filter(p => p.isReported).length,
    totalTradesLogged: raw.trades.length,
  });
});

// ==================== VITE SPA SETUP ====================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Smart Forex Hub server active at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
