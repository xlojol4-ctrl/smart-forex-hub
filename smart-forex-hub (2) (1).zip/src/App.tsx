/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { RiskBanner } from './components/RiskBanner.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { LegalModal, type LegalModalType } from './components/LegalModal.tsx';

import { HomePage } from './pages/HomePage.tsx';
import { LearningCenterPage } from './pages/LearningCenterPage.tsx';
import { TutorialsPage } from './pages/TutorialsPage.tsx';
import { ResourcesPage } from './pages/ResourcesPage.tsx';
import { CalculatorsPage } from './pages/CalculatorsPage.tsx';
import { JournalPage } from './pages/JournalPage.tsx';
import { CalendarNewsPage } from './pages/CalendarNewsPage.tsx';
import { AiAssistantPage } from './pages/AiAssistantPage.tsx';
import { CommunityPage } from './pages/CommunityPage.tsx';
import { AdminPage } from './pages/AdminPage.tsx';

import type { Course, Lesson, Tutorial, ResourceItem, EconomicEvent, PlatformAnnouncement } from './types/index.ts';

const MainAppContent: React.FC = () => {
  const { lang, t } = useLanguage();
  const { isAdmin } = useAuth();

  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [legalModalType, setLegalModalType] = useState<LegalModalType>(null);

  // Global Content State from backend
  const [courses, setCourses] = useState<Course[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [resources, setResources] = useState<ResourceItem[]>([]);
  const [events, setEvents] = useState<EconomicEvent[]>([]);
  const [announcements, setAnnouncements] = useState<PlatformAnnouncement[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchGlobalData = async () => {
    try {
      const [resC, resL, resT, resR, resE, resA] = await Promise.all([
        fetch('/api/courses'),
        fetch('/api/lessons'),
        fetch('/api/tutorials'),
        fetch('/api/resources'),
        fetch('/api/calendar'),
        fetch('/api/announcements'),
      ]);

      if (resC.ok) {
        const data = await resC.json();
        setCourses(data.courses || []);
      }
      if (resL.ok) {
        const data = await resL.json();
        setLessons(data.lessons || []);
      }
      if (resT.ok) {
        const data = await resT.json();
        setTutorials(data.tutorials || []);
      }
      if (resR.ok) {
        const data = await resR.json();
        setResources(data.resources || []);
      }
      if (resE.ok) {
        const data = await resE.json();
        setEvents(data.events || []);
      }
      if (resA.ok) {
        const data = await resA.json();
        setAnnouncements(data.announcements || []);
      }
    } catch (e) {
      console.error('Error fetching global platform data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGlobalData();
  }, []);

  // Sync window scroll when changing tabs
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0A0F1D] text-slate-100 font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* High-Risk Regulatory Banner */}
      <RiskBanner />

      {/* Announcements Bar (if any) */}
      {announcements.length > 0 && announcements[0].active && (
        <div className="bg-emerald-950/40 border-b border-emerald-900/40 px-4 py-2 text-xs text-emerald-300">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <span className="font-semibold">
              📢 {lang === 'en' ? announcements[0].titleEn : announcements[0].titleBn}:
            </span>
            <span className="text-slate-300 line-clamp-1">
              {lang === 'en' ? announcements[0].messageEn : announcements[0].messageBn}
            </span>
          </div>
        </div>
      )}

      {/* Navigation Header */}
      <Navbar activeTab={activeTab} setActiveTab={handleTabChange} />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6">
        {activeTab === 'home' && (
          <HomePage
            courses={courses}
            setActiveTab={handleTabChange}
            setSelectedCourseId={setSelectedCourseId}
          />
        )}

        {activeTab === 'learning' && (
          <LearningCenterPage
            courses={courses}
            lessons={lessons}
            selectedCourseId={selectedCourseId}
            setSelectedCourseId={setSelectedCourseId}
          />
        )}

        {activeTab === 'tutorials' && (
          <TutorialsPage tutorials={tutorials} />
        )}

        {activeTab === 'resources' && (
          <ResourcesPage resources={resources} />
        )}

        {activeTab === 'calculators' && (
          <CalculatorsPage />
        )}

        {activeTab === 'journal' && (
          <JournalPage />
        )}

        {activeTab === 'calendar' && (
          <CalendarNewsPage events={events} />
        )}

        {activeTab === 'ai' && (
          <AiAssistantPage />
        )}

        {activeTab === 'community' && (
          <CommunityPage />
        )}

        {activeTab === 'admin' && (
          <AdminPage
            courses={courses}
            lessons={lessons}
            refreshData={fetchGlobalData}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        setActiveTab={handleTabChange}
        openLegalModal={(type) => setLegalModalType(type)}
      />

      {/* Auth Modal */}
      <AuthModal />

      {/* Legal & Risk Modal */}
      <LegalModal
        type={legalModalType}
        onClose={() => setLegalModalType(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <MainAppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}
