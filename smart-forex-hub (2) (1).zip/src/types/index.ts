export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'trader';
  avatar?: string;
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  questionEn: string;
  questionBn: string;
  optionsEn: string[];
  optionsBn: string[];
  correctAnswer: number;
  explanationEn: string;
  explanationBn: string;
}

export interface Lesson {
  id: string;
  courseId: string;
  titleEn: string;
  titleBn: string;
  slug: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  readTimeMinutes: number;
  order: number;
  summaryEn: string;
  summaryBn: string;
  contentEn: string;
  contentBn: string;
  keyTakeawaysEn: string[];
  keyTakeawaysBn: string[];
  quiz?: QuizQuestion[];
  isPublished: boolean;
  createdAt: string;
}

export interface Course {
  id: string;
  titleEn: string;
  titleBn: string;
  slug: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  summaryEn: string;
  summaryBn: string;
  icon: string;
  order: number;
  isPublished: boolean;
  lessonsCount?: number;
}

export interface Tutorial {
  id: string;
  titleEn: string;
  titleBn: string;
  category: 'exness' | 'tradingview' | 'metatrader' | 'security';
  readTime: string;
  steps: {
    titleEn: string;
    titleBn: string;
    descriptionEn: string;
    descriptionBn: string;
    tipEn?: string;
    tipBn?: string;
  }[];
  isPublished: boolean;
}

export interface ResourceItem {
  id: string;
  titleEn: string;
  titleBn: string;
  category: 'cheatsheet' | 'checklist' | 'glossary' | 'template';
  format: 'PDF' | 'Interactive' | 'Guide';
  descriptionEn: string;
  descriptionBn: string;
  downloadUrl?: string;
  contentEn?: string;
  contentBn?: string;
}

export interface TradeRecord {
  id: string;
  userId: string;
  date: string;
  pair: string;
  type: 'BUY' | 'SELL';
  lotSize: number;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  exitPrice?: number;
  status: 'OPEN' | 'WIN' | 'LOSS' | 'BREAKEVEN';
  pnl?: number;
  pips?: number;
  strategy: string;
  emotion?: 'Disciplined' | 'FOMO' | 'Hesitant' | 'Aggressive' | 'Patient';
  notes: string;
  createdAt: string;
}

export interface EconomicEvent {
  id: string;
  time: string;
  currency: string;
  eventEn: string;
  eventBn: string;
  impact: 'HIGH' | 'MEDIUM' | 'LOW';
  actual?: string;
  forecast?: string;
  previous?: string;
  descriptionEn: string;
  descriptionBn: string;
}

export interface CommunityComment {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userRole: 'admin' | 'trader';
  content: string;
  createdAt: string;
}

export interface CommunityPost {
  id: string;
  userId: string;
  userName: string;
  userRole: 'admin' | 'trader';
  title: string;
  content: string;
  category: 'beginner' | 'strategy' | 'technical' | 'psychology' | 'brokers';
  likesCount: number;
  commentsCount: number;
  isReported: boolean;
  status: 'approved' | 'pending' | 'rejected';
  createdAt: string;
  comments?: CommunityComment[];
}

export interface PlatformAnnouncement {
  id: string;
  titleEn: string;
  titleBn: string;
  messageEn: string;
  messageBn: string;
  type: 'info' | 'warning' | 'alert' | 'success';
  active: boolean;
  createdAt: string;
}

export interface AiChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}
