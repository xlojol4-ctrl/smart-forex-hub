import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { Clock } from 'lucide-react';

interface Session {
  nameKey: 'sessionSydney' | 'sessionTokyo' | 'sessionLondon' | 'sessionNewYork';
  startUtcHour: number;
  endUtcHour: number;
  center: string;
}

const SESSIONS: Session[] = [
  { nameKey: 'sessionSydney', startUtcHour: 21, endUtcHour: 6, center: 'Sydney (21:00 - 06:00 UTC)' },
  { nameKey: 'sessionTokyo', startUtcHour: 0, endUtcHour: 9, center: 'Tokyo (00:00 - 09:00 UTC)' },
  { nameKey: 'sessionLondon', startUtcHour: 8, endUtcHour: 16, center: 'London (08:00 - 16:00 UTC)' },
  { nameKey: 'sessionNewYork', startUtcHour: 13, endUtcHour: 22, center: 'New York (13:00 - 22:00 UTC)' },
];

function isSessionOpen(nowUtcHour: number, start: number, end: number): boolean {
  if (start < end) {
    return nowUtcHour >= start && nowUtcHour < end;
  }
  // Wraps midnight
  return nowUtcHour >= start || nowUtcHour < end;
}

export const MarketSessionsClock: React.FC = () => {
  const { t } = useLanguage();
  const [currentUtc, setCurrentUtc] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentUtc(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const utcHour = currentUtc.getUTCHours();
  const utcFormatted = currentUtc.toUTCString().slice(17, 25) + ' UTC';

  return (
    <div className="bg-[#0f172a]/80 border border-slate-800 rounded-xl p-3 md:p-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <Clock className="w-4 h-4 text-emerald-400" />
          <span>{t.marketSessions}</span>
        </div>
        <div className="text-xs font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
          {utcFormatted}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {SESSIONS.map(session => {
          const isOpen = isSessionOpen(utcHour, session.startUtcHour, session.endUtcHour);
          return (
            <div
              key={session.nameKey}
              className={`p-2 rounded-lg border text-xs transition-colors ${
                isOpen
                  ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                  : 'bg-slate-900/50 border-slate-800 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between font-medium">
                <span>{t[session.nameKey]}</span>
                <span
                  className={`inline-block w-2 h-2 rounded-full ${
                    isOpen ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
                  }`}
                />
              </div>
              <div className="mt-1 text-[11px] opacity-80 flex items-center justify-between">
                <span>{isOpen ? t.sessionOpen : t.sessionClosed}</span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {session.startUtcHour.toString().padStart(2, '0')}:00
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
