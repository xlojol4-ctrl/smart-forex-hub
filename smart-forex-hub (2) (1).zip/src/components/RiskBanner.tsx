import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { AlertTriangle } from 'lucide-react';

export const RiskBanner: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="bg-amber-950/20 border-b border-amber-900/30 px-4 py-2 text-xs text-amber-300/90">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <p className="line-clamp-1 sm:line-clamp-none">
            {t.riskWarningShort}
          </p>
        </div>
      </div>
    </div>
  );
};
