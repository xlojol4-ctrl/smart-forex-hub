import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { TrendingUp, ShieldAlert, BookOpen, Calculator, FileText, Heart } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
  openLegalModal: (page: 'about' | 'contact' | 'privacy' | 'terms' | 'disclaimer') => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, openLegalModal }) => {
  const { lang, t } = useLanguage();

  return (
    <footer className="bg-[#070B16] border-t border-slate-800/80 text-slate-400 text-xs mt-16">
      {/* High-visibility regulatory warning */}
      <div className="bg-[#0b132b]/60 border-b border-slate-800/60 py-6 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-start gap-3 text-slate-300">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1.5 text-[11px] leading-relaxed">
              <p className="font-semibold text-amber-300 uppercase tracking-wider">
                {lang === 'en' ? 'Statutory High-Risk Investment Warning' : 'বিধিবদ্ধ উচ্চ ঝুঁকির বিনিয়োগ সতর্কতা'}
              </p>
              <p className="text-slate-400">
                {lang === 'en'
                  ? 'Trading foreign exchange (Forex) and Contracts for Difference (CFDs) on margin carries a high level of risk and may not be suitable for all investors. The high degree of leverage can work against you as well as for you. Before deciding to trade, you should carefully consider your investment objectives, level of experience, and risk appetite. There is a possibility that you could sustain a loss of some or all of your initial investment; do not invest money that you cannot afford to lose.'
                  : 'মার্জিনে বৈদেশিক মুদ্রা (ফরেক্স) এবং সিএফডি লেনদেন অত্যন্ত ঝুঁকিপূর্ণ এবং এটি সকল বিনিয়োগকারীর জন্য উপযুক্ত নাও হতে পারে। উচ্চ লিভারেজের সুবিধা লাভের মতো লোকসানকেও বহুগুণ বাড়িয়ে দিতে পারে। ট্রেড শুরু করার আগে আপনার আর্থিক লক্ষ্য, অভিজ্ঞতা এবং ঝুঁকি গ্রহণের সক্ষমতা গভীরভাবে বিবেচনা করুন। প্রাথমিক বিনিয়োগের আংশিক বা সম্পূর্ণ হারানোর ঝুঁকি বিদ্যমান; এমন অর্থ কখনই বিনিয়োগ করবেন না যা হারানোর সামর্থ্য আপনার নেই।'}
              </p>
              <p className="text-slate-500 text-[10px]">
                {lang === 'en'
                  ? 'Smart Forex Hub provides educational content and analytical utilities only. We do not provide financial advice, broker dealer services, or guaranteed trading signals.'
                  : 'স্মার্ট ফরেক্স হাব কেবল শিক্ষামূলক বিষয়বস্তু ও গাণিতিক টুলস সরবরাহ করে। আমরা কোনো ফিন্যান্সিয়াল অ্যাডভাইস, ব্রোকারেজ সার্ভিস বা সিগন্যাল প্রদান করি না।'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Sitemap */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Column */}
        <div className="space-y-3 md:col-span-1">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-slate-950 font-bold" />
            </div>
            <span className="font-bold text-white text-sm">{t.brandName}</span>
          </div>
          <p className="text-[12px] text-slate-400 leading-relaxed">
            {t.tagline}. Institutional-level risk education, high-precision position sizing calculators, and personal journal tools.
          </p>
          <div className="text-[11px] text-emerald-400/90 font-mono">
            v2.4 Production · Verified Architecture
          </div>
        </div>

        {/* Education Links */}
        <div>
          <h4 className="font-semibold text-white text-xs uppercase tracking-wider mb-3">
            {lang === 'en' ? 'Education' : 'শিক্ষা ও কোর্স'}
          </h4>
          <ul className="space-y-2 text-[12px]">
            <li>
              <button onClick={() => setActiveTab('learning')} className="hover:text-emerald-400 transition-colors">
                {t.navLearning}
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('tutorials')} className="hover:text-emerald-400 transition-colors">
                {t.navTutorials} (Exness & TradingView)
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('resources')} className="hover:text-emerald-400 transition-colors">
                {t.navResources} & Cheat Sheets
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('ai')} className="hover:text-emerald-400 transition-colors">
                {t.navAi}
              </button>
            </li>
          </ul>
        </div>

        {/* Utilities Links */}
        <div>
          <h4 className="font-semibold text-white text-xs uppercase tracking-wider mb-3">
            {lang === 'en' ? 'Trading Utilities' : 'ট্রেডিং ইউটিলিটি'}
          </h4>
          <ul className="space-y-2 text-[12px]">
            <li>
              <button onClick={() => setActiveTab('calculators')} className="hover:text-emerald-400 transition-colors">
                {t.calcTabPosition}
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('calculators')} className="hover:text-emerald-400 transition-colors">
                {t.calcTabMargin}
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('journal')} className="hover:text-emerald-400 transition-colors">
                {t.navJournal}
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('calendar')} className="hover:text-emerald-400 transition-colors">
                {t.navCalendar}
              </button>
            </li>
          </ul>
        </div>

        {/* Legal & Policies */}
        <div>
          <h4 className="font-semibold text-white text-xs uppercase tracking-wider mb-3">
            {lang === 'en' ? 'Transparency & Legal' : 'স্বচ্ছতা ও নীতিমালা'}
          </h4>
          <ul className="space-y-2 text-[12px]">
            <li>
              <button onClick={() => openLegalModal('about')} className="hover:text-emerald-400 transition-colors">
                About Smart Forex Hub
              </button>
            </li>
            <li>
              <button onClick={() => openLegalModal('contact')} className="hover:text-emerald-400 transition-colors">
                Contact & Support
              </button>
            </li>
            <li>
              <button onClick={() => openLegalModal('disclaimer')} className="hover:text-emerald-400 transition-colors text-amber-400/90">
                Full Risk Disclaimer
              </button>
            </li>
            <li>
              <button onClick={() => openLegalModal('privacy')} className="hover:text-emerald-400 transition-colors">
                Privacy Policy
              </button>
            </li>
            <li>
              <button onClick={() => openLegalModal('terms')} className="hover:text-emerald-400 transition-colors">
                Terms of Service
              </button>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-slate-800/60 py-4 px-4 text-center text-[11px] text-slate-500">
        <p>© 2026 {t.brandName}. All rights reserved. Built for disciplined currency market students worldwide.</p>
      </div>
    </footer>
  );
};
