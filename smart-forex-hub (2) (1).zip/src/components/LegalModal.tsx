import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { X, ShieldCheck, Mail, FileText, AlertTriangle, Info } from 'lucide-react';

export type LegalModalType = 'about' | 'contact' | 'privacy' | 'terms' | 'disclaimer' | null;

interface LegalModalProps {
  type: LegalModalType;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ type, onClose }) => {
  const { lang } = useLanguage();

  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl text-slate-200 max-h-[85vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {type === 'about' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
              <Info className="w-4 h-4" />
              <span>About Smart Forex Hub</span>
            </div>
            <h2 className="text-xl font-bold text-white">Our Mission: Disciplined Forex Education</h2>
            <div className="text-xs sm:text-sm text-slate-300 space-y-3 leading-relaxed">
              <p>
                Smart Forex Hub was founded to counter the proliferation of fraudulent get-rich-quick schemes, unregulated signal groups, and predatory retail Forex marketing.
              </p>
              <p>
                Our philosophy is grounded in probability, capital preservation, and institutional mathematical sizing. We believe that no trader can survive long-term without strict position sizing (1% rule), a documented trading journal, and emotional detachment.
              </p>
              <p>
                Whether you speak English or বাংলা (Bengali), Smart Forex Hub equips you with foundational mechanics, Exness account onboarding security, TradingView charting skills, and Gemini AI study assistance.
              </p>
            </div>
          </div>
        )}

        {type === 'contact' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
              <Mail className="w-4 h-4" />
              <span>Contact & Student Support</span>
            </div>
            <h2 className="text-xl font-bold text-white">Get in Touch with our Editorial Team</h2>
            <div className="text-xs sm:text-sm text-slate-300 space-y-3 leading-relaxed">
              <p>
                Have a question about a lesson, found a typo, or want to contribute original research materials? Reach out directly.
              </p>
              <div className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 space-y-2 font-mono text-xs">
                <div><span className="text-slate-400">Official Inquiries:</span> <span className="text-emerald-400">contact@smartforexhub.com</span></div>
                <div><span className="text-slate-400">Editorial & Submissions:</span> <span className="text-emerald-400">editor@smartforexhub.com</span></div>
                <div><span className="text-slate-400">Admin Dispatch:</span> <span className="text-emerald-400">admin@smartforexhub.com</span></div>
              </div>
              <p className="text-xs text-slate-400">
                Note: We do NOT provide personalized trading signals, account management, or financial advisory via email or private channels.
              </p>
            </div>
          </div>
        )}

        {type === 'disclaimer' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>Statutory Risk Disclaimer</span>
            </div>
            <h2 className="text-xl font-bold text-white">Complete Risk & Leverage Disclosure</h2>
            <div className="text-xs sm:text-sm text-slate-300 space-y-3 leading-relaxed">
              <p className="font-semibold text-amber-300">
                1. High Risk of Investment Loss
              </p>
              <p>
                Trading foreign exchange (Forex) and CFDs on margin involves high risk of loss and is not appropriate for all investors. Retail investor accounts frequently lose money when trading CFDs due to the effects of leverage.
              </p>
              <p className="font-semibold text-amber-300">
                2. No Financial Advice or Guarantees
              </p>
              <p>
                All materials, courses, calculators, tutorials, and AI-generated responses provided on Smart Forex Hub are for educational and informational purposes only. Nothing on this website constitutes legal, financial, taxation, or investment advice.
              </p>
              <p className="font-semibold text-amber-300">
                3. Historical Performance Not Predictive
              </p>
              <p>
                Past performance is not an indication of future results. No representation is made that any account will achieve profits or losses similar to those discussed in tutorials or example trade scenarios.
              </p>
            </div>
          </div>
        )}

        {type === 'privacy' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
              <ShieldCheck className="w-4 h-4" />
              <span>Privacy Policy</span>
            </div>
            <h2 className="text-xl font-bold text-white">Your Data & Privacy Rights</h2>
            <div className="text-xs sm:text-sm text-slate-300 space-y-3 leading-relaxed">
              <p>
                At Smart Forex Hub, we respect your privacy. Personal trade journal records logged by registered traders are strictly isolated to each respective user account. We never sell or share trade journal data, notes, or strategies with third parties or broker marketing networks.
              </p>
              <p>
                Authentication credentials are protected using salted SHA-256 password hashing. You can export your full trade journal at any time in standard CSV format or request complete account deletion.
              </p>
            </div>
          </div>
        )}

        {type === 'terms' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
              <FileText className="w-4 h-4" />
              <span>Terms of Service</span>
            </div>
            <h2 className="text-xl font-bold text-white">Platform Usage & Community Conduct</h2>
            <div className="text-xs sm:text-sm text-slate-300 space-y-3 leading-relaxed">
              <p>
                By using Smart Forex Hub, you agree not to use the platform for unlawful activities, distribute malicious code, spam the community forum with affiliate links or commercial solicitations, or harass other students.
              </p>
              <p>
                Only platform administrators may publish official courses, lessons, and certification notes. Community contributions are subject to moderation and violation of community guidelines will result in account suspension.
              </p>
            </div>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition-colors"
          >
            Close Window
          </button>
        </div>
      </div>
    </div>
  );
};
