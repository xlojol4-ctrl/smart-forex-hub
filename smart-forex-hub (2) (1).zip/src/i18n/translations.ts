export type Language = 'en' | 'bn';

export const translations = {
  en: {
    // Brand
    brandName: 'Smart Forex Hub',
    tagline: 'Professional Forex Education & Utility Platform',
    
    // Navigation
    navHome: 'Home',
    navLearning: 'Learning Center',
    navTutorials: 'Tutorials',
    navResources: 'Resources',
    navCalculators: 'Calculators',
    navJournal: 'Trading Journal',
    navCalendar: 'Calendar & News',
    navAi: 'Forex AI',
    navCommunity: 'Community',
    navAdmin: 'Admin Panel',
    navSignIn: 'Sign In',
    navSignUp: 'Get Started',
    navSignOut: 'Sign Out',
    
    // Hero
    heroTitlePrefix: 'Master Currency Trading with',
    heroTitleAccent: 'Discipline & Pure Mathematics',
    heroSubtitle: 'No fake signals, no get-rich-quick scams. Institutional-grade Forex education, tested risk calculators, personal journal tracking, and bilingual AI mentoring.',
    heroCtaCourses: 'Explore Courses',
    heroCtaCalculators: 'Open Calculators',
    heroCtaAi: 'Ask AI Mentor',

    // Sessions
    marketSessions: 'Global Market Sessions',
    sessionLondon: 'London',
    sessionNewYork: 'New York',
    sessionTokyo: 'Tokyo',
    sessionSydney: 'Sydney',
    sessionOpen: 'OPEN',
    sessionClosed: 'CLOSED',

    // Featured stats / highlights
    statLessons: 'Structured Lessons',
    statCalculators: 'Tested Financial Tools',
    statBilingual: 'English & বাংলা',
    statNoSignals: '100% Educational',

    // Common
    searchPlaceholder: 'Search lessons, tutorials, and concepts...',
    filterAll: 'All',
    beginner: 'Beginner',
    intermediate: 'Intermediate',
    advanced: 'Advanced',
    readTime: 'min read',
    keyTakeaways: 'Key Takeaways',
    takeQuiz: 'Test Your Knowledge',
    quizSubmitted: 'Quiz Completed',
    quizScore: 'Your Score',
    nextLesson: 'Next Lesson',
    prevLesson: 'Previous Lesson',
    backToCourses: 'Back to Courses',

    // Calculators
    calcTitle: 'Institutional Forex Calculators',
    calcSubtitle: 'Protect your account balance with rigorous mathematical sizing and margin rules.',
    calcTabPosition: 'Position & Lot Size',
    calcTabRiskSl: 'Risk % & Stop Loss',
    calcTabPip: 'Pip Value',
    calcTabMargin: 'Margin Requirement',
    calcTabRr: 'Risk-to-Reward',
    calcTabProfit: 'Profit/Loss Estimator',
    calcBalance: 'Account Balance ($)',
    calcRiskPercent: 'Risk Percentage (%)',
    calcStopLossPips: 'Stop Loss (Pips)',
    calcCurrencyPair: 'Currency Pair',
    calcCalculate: 'Calculate',
    calcReset: 'Reset',
    calcResultLotSize: 'Recommended Lot Size',
    calcResultRiskAmount: 'Capital at Risk',
    calcResultPipValue: 'Pip Value',
    calcDisclaimer: 'Estimates are mathematical models. Actual execution prices, pip values, and required margin vary by broker spreads, slippage, and instrument specifications.',

    // Journal
    journalTitle: 'Personal Trading Journal',
    journalSubtitle: 'Track every execution, analyze your win rate, and develop institutional discipline.',
    journalNewTrade: 'Log New Trade',
    journalFilterPair: 'Filter by Pair',
    journalExportCsv: 'Export CSV',
    journalWinRate: 'Win Rate',
    journalTotalTrades: 'Total Trades',
    journalNetPnL: 'Net P&L ($)',
    journalProfitFactor: 'Profit Factor',
    journalOpenTrades: 'Open Trades',
    journalColDate: 'Date',
    journalColPair: 'Pair',
    journalColType: 'Type',
    journalColLots: 'Lots',
    journalColEntry: 'Entry',
    journalColSl: 'Stop Loss',
    journalColTp: 'Take Profit',
    journalColStatus: 'Status',
    journalColPnl: 'P&L ($)',
    journalColActions: 'Actions',
    journalNoTrades: 'No trades logged yet. Start recording your trade history today.',

    // AI Assistant
    aiTitle: 'Forex AI Educational Mentor',
    aiSubtitle: 'Dedicated educational assistant powered by Gemini. Ask any concept in English or বাংলা.',
    aiPlaceholder: 'Ask a question (e.g. "How does 1:100 leverage work?" or "পিপ কি এবং কিভাবে হিসাব করে?")...',
    aiSend: 'Send',
    aiDisclaimer: 'Educational mentor only. Smart Forex Hub never provides financial advice, guaranteed predictions, or buy/sell signals. Trading involves high risk of loss.',
    aiQuickPrompts: 'Popular Topics',

    // Community
    communityTitle: 'Trader Study Forum',
    communitySubtitle: 'Discuss educational strategies, ask questions, and share study notes.',
    communityNewPost: 'Create Discussion Post',
    communityReport: 'Report',
    communityComments: 'Comments',
    communityReply: 'Leave a reply...',

    // Admin
    adminTitle: 'Administrator Control Panel',
    adminSubtitle: 'Manage courses, lessons, tutorials, announcements, and moderate community content.',
    adminAddLesson: 'Create Lesson',
    adminManagePosts: 'Community Moderation',
    adminPlatformStats: 'Platform Overview',

    // Risk Warning
    riskWarningShort: 'High Risk Warning: Forex & CFD trading on margin carries a high level of risk and may not be suitable for all investors. Never trade with money you cannot afford to lose.',
    
    // Auth
    loginTitle: 'Welcome Back',
    loginSubtitle: 'Sign in to access your personal journal and community features.',
    registerTitle: 'Create Account',
    registerSubtitle: 'Join Smart Forex Hub to track trades and save progress.',
    emailLabel: 'Email Address',
    passwordLabel: 'Password',
    nameLabel: 'Full Name',
    btnSignIn: 'Sign In',
    btnRegister: 'Create Account',
    quickAdminDemo: 'Quick Demo Admin Sign In',
  },
  bn: {
    // Brand
    brandName: 'স্মার্ট ফরেক্স হাব',
    tagline: 'প্রফেশনাল ফরেক্স শিক্ষা ও ইউটিলিটি প্ল্যাটফর্ম',

    // Navigation
    navHome: 'হোম',
    navLearning: 'লার্নিং সেন্টার',
    navTutorials: 'টিউটোরিয়াল',
    navResources: 'রিসোর্স',
    navCalculators: 'ক্যালকুলেটর',
    navJournal: 'ট্রেডিং জার্নাল',
    navCalendar: 'ক্যালেন্ডার ও নিউজ',
    navAi: 'ফরেক্স এআই',
    navCommunity: 'কমিউনিটি',
    navAdmin: 'অ্যাডমিন প্যানেল',
    navSignIn: 'লগইন',
    navSignUp: 'শুরু করুন',
    navSignOut: 'লগআউট',

    // Hero
    heroTitlePrefix: 'মুদ্রা বাজারে দক্ষতা অর্জন করুন',
    heroTitleAccent: 'শৃঙ্খলা ও নিখুঁত গণিতের শক্তিতে',
    heroSubtitle: 'কোনো ভুয়া সিগন্যাল বা অলীক লোভ নয়। বাস্তবসম্মত আন্তর্জাতিক ফরেক্স শিক্ষা, পরীক্ষিত রিস্ক ক্যালকুলেটর, ব্যক্তিগত জার্নাল এবং দ্বিভাষিক এআই মেন্টর।',
    heroCtaCourses: 'কোর্সগুলো দেখুন',
    heroCtaCalculators: 'ক্যালকুলেটর খুলুন',
    heroCtaAi: 'এআই মেন্টরকে প্রশ্ন করুন',

    // Sessions
    marketSessions: 'আন্তর্জাতিক মার্কেট সেশন',
    sessionLondon: 'লন্ডন',
    sessionNewYork: 'নিউ ইয়র্ক',
    sessionTokyo: 'টোকিও',
    sessionSydney: 'সিডনি',
    sessionOpen: 'খোলা',
    sessionClosed: 'বন্ধ',

    // Featured stats
    statLessons: 'কাঠামোগত পাঠ',
    statCalculators: 'পরীক্ষিত আর্থিক ক্যালকুলেটর',
    statBilingual: 'বাংলা ও ইংরেজি',
    statNoSignals: '১০০% শিক্ষামূলক',

    // Common
    searchPlaceholder: 'পাঠ, টিউটোরিয়াল ও ফরেক্স শব্দ খুঁজুন...',
    filterAll: 'সকল',
    beginner: 'নতুনদের জন্য',
    intermediate: 'মধ্যবর্তী',
    advanced: 'উন্নত',
    readTime: 'মিনিট পড়ার সময়',
    keyTakeaways: 'মূল সারসংক্ষেপ',
    takeQuiz: 'কুইজ দিয়ে যাচাই করুন',
    quizSubmitted: 'কুইজ সম্পন্ন হয়েছে',
    quizScore: 'আপনার স্কোর',
    nextLesson: 'পরবর্তী পাঠ',
    prevLesson: 'পূর্ববর্তী পাঠ',
    backToCourses: 'কোর্সে ফিরে যান',

    // Calculators
    calcTitle: 'আন্তর্জাতিক ফরেক্স ক্যালকুলেটর',
    calcSubtitle: 'সঠিক গণিত ও মার্জিন নিয়মের মাধ্যমে আপনার মূলধন রক্ষা করুন।',
    calcTabPosition: 'পজিশন ও লট সাইজ',
    calcTabRiskSl: 'রিস্ক % ও স্টপ লস',
    calcTabPip: 'পিপ ভ্যালু',
    calcTabMargin: 'প্রয়োজনীয় মার্জিন',
    calcTabRr: 'রিস্ক-টু-রিওয়ার্ড',
    calcTabProfit: 'লাভ-ক্ষতি পরিমাপক',
    calcBalance: 'অ্যাকাউন্ট ব্যালেন্স ($)',
    calcRiskPercent: 'ঝুঁকির শতকরা হার (%)',
    calcStopLossPips: 'স্টপ লস (পিপ্স)',
    calcCurrencyPair: 'কারেন্সি পেয়ার',
    calcCalculate: 'হিসেব করুন',
    calcReset: 'রিসেট',
    calcResultLotSize: 'সুপারিশকৃত লট সাইজ',
    calcResultRiskAmount: 'ঝুঁকিপূর্ণ মূলধন ($)',
    calcResultPipValue: 'পিপের মূল্য',
    calcDisclaimer: 'গণনাগুলো স্ট্যান্ডার্ড গাণিতিক সূত্রভিত্তিক। ব্রোকারের স্প্রেড ও স্লিপেজ অনুযায়ী বাস্তব ফলাফলে সামান্য তারতম্য হতে পারে।',

    // Journal
    journalTitle: 'ব্যক্তিগত ট্রেডিং জার্নাল',
    journalSubtitle: 'প্রতিটি ট্রেড রেকর্ড রাখুন, উইন রেট বিশ্লেষণ করুন এবং শৃঙ্খলা তৈরি করুন।',
    journalNewTrade: 'নতুন ট্রেড যুক্ত করুন',
    journalFilterPair: 'পেয়ার দিয়ে ফিল্টার',
    journalExportCsv: 'সিএসভি (CSV) এক্সপোর্ট',
    journalWinRate: 'উইন রেট',
    journalTotalTrades: 'মোট ট্রেড',
    journalNetPnL: 'মোট লাভ/ক্ষতি ($)',
    journalProfitFactor: 'প্রফিট ফ্যাক্টর',
    journalOpenTrades: 'খোলা ট্রেড',
    journalColDate: 'তারিখ',
    journalColPair: 'পেয়ার',
    journalColType: 'টাইপ',
    journalColLots: 'লট',
    journalColEntry: 'এন্ট্রি',
    journalColSl: 'স্টপ লস',
    journalColTp: 'টেক প্রফিট',
    journalColStatus: 'স্ট্যাটাস',
    journalColPnl: 'লাভ/ক্ষতি ($)',
    journalColActions: 'অ্যাকশন',
    journalNoTrades: 'এখনো কোনো ট্রেড যুক্ত করা হয়নি। আজই আপনার ট্রেডিং রেকর্ড রাখা শুরু করুন।',

    // AI Assistant
    aiTitle: 'ফরেক্স এআই শিক্ষামূলক মেন্টর',
    aiSubtitle: 'জেমিনাই চালিত ডেডিকেটেড ফরেক্স মেন্টর। বাংলা বা ইংরেজিতে যেকোনো প্রশ্ন জিজ্ঞেস করুন।',
    aiPlaceholder: 'যেকোনো প্রশ্ন লিখুন (যেমন: "লিভারেজ ১:১০০ কিভাবে কাজ করে?" বা "সাপোর্ট ও রেজিস্ট্যান্স কিভাবে আঁকব?")...',
    aiSend: 'পাঠান',
    aiDisclaimer: 'শুধুমাত্র শিক্ষামূলক উদ্দেশ্যে প্রস্তুত। স্মার্ট ফরেক্স হাব কোনো ফিন্যান্সিয়াল অ্যাডভাইস, সিগন্যাল বা লাভের নিশ্চয়তা প্রদান করে না।',
    aiQuickPrompts: 'জনপ্রিয় বিষয়সমূহ',

    // Community
    communityTitle: 'ট্রেডারদের শিক্ষামূলক ফোরাম',
    communitySubtitle: 'কৌশল আলোচনা করুন, প্রশ্ন করুন এবং নোট বিনিময় করুন।',
    communityNewPost: 'নতুন আলোচনা পোস্ট',
    communityReport: 'রিপোর্ট করুন',
    communityComments: 'মন্তব্যসমূহ',
    communityReply: 'একটি মন্তব্য লিখুন...',

    // Admin
    adminTitle: 'অ্যাডমিনিস্ট্রেটর কন্ট্রোল প্যানেল',
    adminSubtitle: 'কোর্স, পাঠ, টিউটোরিয়াল এবং কমিউনিটি পোস্ট নিয়ন্ত্রণ করুন।',
    adminAddLesson: 'নতুন পাঠ তৈরি করুন',
    adminManagePosts: 'কমিউনিটি মডারেশন',
    adminPlatformStats: 'প্ল্যাটফর্মের সার্বিক তথ্য',

    // Risk Warning
    riskWarningShort: 'উচ্চ ঝুঁকির সতর্কতা: মার্জিনে ফরেক্স ও সিএফডি ট্রেডিং অত্যন্ত ঝুঁকিপূর্ণ এবং সবার জন্য উপযুক্ত নাও হতে পারে। এমন অর্থ দিয়ে কখনোই ট্রেড করবেন না যা হারানোর সামর্থ্য আপনার নেই।',

    // Auth
    loginTitle: 'ফিরে আসায় স্বাগতম',
    loginSubtitle: 'ব্যক্তিগত জার্নাল ও ফোরামে প্রবেশ করতে সাইন ইন করুন।',
    registerTitle: 'অ্যাকাউন্ট তৈরি করুন',
    registerSubtitle: 'স্মার্ট ফরেক্স হাবে যুক্ত হয়ে ট্রেড রেকর্ড সংরক্ষণ করুন।',
    emailLabel: 'ইমেইল এড্রেস',
    passwordLabel: 'পাসওয়ার্ড',
    nameLabel: 'আপনার পূর্ণ নাম',
    btnSignIn: 'সাইন ইন',
    btnRegister: 'রেজিস্ট্রেশন করুন',
    quickAdminDemo: 'অ্যাডমিন ডেমো লগইন',
  }
};
