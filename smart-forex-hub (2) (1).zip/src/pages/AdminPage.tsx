import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import type { Lesson, Course, CommunityPost, PlatformAnnouncement } from '../types/index.ts';
import { 
  Shield, BookOpen, Users, Plus, Trash2, Edit2, CheckCircle2, 
  XCircle, AlertTriangle, Eye, EyeOff, BarChart2, Bell, RefreshCw
} from 'lucide-react';

interface AdminPageProps {
  courses: Course[];
  lessons: Lesson[];
  refreshData: () => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ courses, lessons, refreshData }) => {
  const { user, isAdmin, getAuthHeaders } = useAuth();
  const { lang, t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'lessons' | 'community' | 'metrics' | 'announcements'>('lessons');
  const [metrics, setMetrics] = useState<any>(null);
  const [reportedPosts, setReportedPosts] = useState<CommunityPost[]>([]);
  const [allPosts, setAllPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);

  // Lesson Edit Modal
  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [lessonFormData, setLessonFormData] = useState({
    titleEn: '',
    titleBn: '',
    courseId: courses[0]?.id || 'course-1',
    difficulty: 'beginner' as 'beginner' | 'intermediate' | 'advanced',
    readTimeMinutes: 5,
    order: 1,
    summaryEn: '',
    summaryBn: '',
    contentEn: '',
    contentBn: '',
    keyTakeawaysEn: '',
    keyTakeawaysBn: '',
    isPublished: true,
  });

  const fetchAdminData = async () => {
    if (!isAdmin) return;
    setLoading(true);
    try {
      const [resMetrics, resPosts] = await Promise.all([
        fetch('/api/admin/metrics', { headers: getAuthHeaders() }),
        fetch('/api/community/posts', { headers: getAuthHeaders() }),
      ]);
      if (resMetrics.ok) {
        const m = await resMetrics.json();
        setMetrics(m);
      }
      if (resPosts.ok) {
        const p = await resPosts.json();
        setAllPosts(p.posts || []);
        setReportedPosts((p.posts || []).filter((item: CommunityPost) => item.isReported));
      }
    } catch (e) {
      console.error('Failed to fetch admin data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchAdminData();
    }
  }, [isAdmin]);

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-red-950/60 border border-red-800/60 text-red-400 flex items-center justify-center mx-auto">
          <Shield className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white">Administrator Access Restricted</h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          This management console requires verified server-side administrator credentials. Ordinary student accounts cannot access or view management commands.
        </p>
      </div>
    );
  }

  const handleOpenAddLesson = () => {
    setEditingLesson(null);
    setLessonFormData({
      titleEn: '',
      titleBn: '',
      courseId: courses[0]?.id || 'course-1',
      difficulty: 'beginner',
      readTimeMinutes: 6,
      order: lessons.length + 1,
      summaryEn: '',
      summaryBn: '',
      contentEn: '### Section 1: Introduction\n\nContent details here...',
      contentBn: '### ১. পরিচিতি\n\nবিস্তারিত পাঠ এখানে...',
      keyTakeawaysEn: 'Rule 1\nRule 2',
      keyTakeawaysBn: 'নিয়ম ১\nনিয়ম ২',
      isPublished: true,
    });
    setIsLessonModalOpen(true);
  };

  const handleOpenEditLesson = (lesson: Lesson) => {
    setEditingLesson(lesson);
    setLessonFormData({
      titleEn: lesson.titleEn,
      titleBn: lesson.titleBn,
      courseId: lesson.courseId,
      difficulty: lesson.difficulty,
      readTimeMinutes: lesson.readTimeMinutes,
      order: lesson.order,
      summaryEn: lesson.summaryEn,
      summaryBn: lesson.summaryBn,
      contentEn: lesson.contentEn,
      contentBn: lesson.contentBn,
      keyTakeawaysEn: lesson.keyTakeawaysEn.join('\n'),
      keyTakeawaysBn: lesson.keyTakeawaysBn.join('\n'),
      isPublished: lesson.isPublished,
    });
    setIsLessonModalOpen(true);
  };

  const handleSaveLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload: Partial<Lesson> = {
        titleEn: lessonFormData.titleEn,
        titleBn: lessonFormData.titleBn,
        courseId: lessonFormData.courseId,
        difficulty: lessonFormData.difficulty,
        readTimeMinutes: Number(lessonFormData.readTimeMinutes),
        order: Number(lessonFormData.order),
        summaryEn: lessonFormData.summaryEn,
        summaryBn: lessonFormData.summaryBn,
        contentEn: lessonFormData.contentEn,
        contentBn: lessonFormData.contentBn,
        keyTakeawaysEn: lessonFormData.keyTakeawaysEn.split('\n').filter(Boolean),
        keyTakeawaysBn: lessonFormData.keyTakeawaysBn.split('\n').filter(Boolean),
        isPublished: lessonFormData.isPublished,
        slug: lessonFormData.titleEn.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      };

      const url = editingLesson ? `/api/admin/lessons/${editingLesson.id}` : '/api/admin/lessons';
      const method = editingLesson ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsLessonModalOpen(false);
        refreshData();
        fetchAdminData();
      }
    } catch (err) {
      console.error('Error saving lesson:', err);
    }
  };

  const handleDeleteLesson = async (id: string) => {
    if (!confirm('Are you sure you want to permanently delete this lesson?')) return;
    try {
      const res = await fetch(`/api/admin/lessons/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });
      if (res.ok) {
        refreshData();
        fetchAdminData();
      }
    } catch (err) {
      console.error('Error deleting lesson:', err);
    }
  };

  const handleModeratePost = async (postId: string, status: 'approved' | 'rejected', deleteItem: boolean) => {
    try {
      const res = await fetch(`/api/admin/community/${postId}/moderate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ status, deleteItem })
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch (e) {
      console.error('Moderation action failed:', e);
    }
  };

  return (
    <div className="space-y-8 py-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <Shield className="w-4 h-4" />
            <span>Authenticated Administrator Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            {t.adminTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            {t.adminSubtitle}
          </p>
        </div>

        <button
          onClick={fetchAdminData}
          className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-2 self-start sm:self-auto transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Admin KPI Metrics */}
      {metrics && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0F172A] border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">Total Users</p>
            <p className="text-xl sm:text-2xl font-black text-emerald-400 font-mono mt-1">
              {metrics.totalUsers}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">Lessons Published</p>
            <p className="text-xl sm:text-2xl font-black text-white font-mono mt-1">
              {lessons.length}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">Community Posts</p>
            <p className="text-xl sm:text-2xl font-black text-teal-400 font-mono mt-1">
              {metrics.totalPosts}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">Reported Posts</p>
            <p className={`text-xl sm:text-2xl font-black font-mono mt-1 ${metrics.reportedPostsCount > 0 ? 'text-red-400' : 'text-slate-400'}`}>
              {metrics.reportedPostsCount}
            </p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#0F172A] border border-slate-800 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab('lessons')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
            activeTab === 'lessons' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          Courses & Lessons ({lessons.length})
        </button>
        <button
          onClick={() => setActiveTab('community')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
            activeTab === 'community' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          Community Moderation ({reportedPosts.length} Reported)
        </button>
      </div>

      {/* Tab: Lessons Management */}
      {activeTab === 'lessons' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Curriculum Management</h3>
            <button
              onClick={handleOpenAddLesson}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-md shadow-emerald-500/20"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Create New Lesson</span>
            </button>
          </div>

          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-[#0a0f1d] text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-4">Title (EN / BN)</th>
                    <th className="py-3 px-4">Course</th>
                    <th className="py-3 px-4">Difficulty</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {lessons.map(lesson => {
                    const course = courses.find(c => c.id === lesson.courseId);
                    return (
                      <tr key={lesson.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-4">
                          <p className="font-bold text-white">{lesson.titleEn}</p>
                          <p className="text-[11px] text-slate-400">{lesson.titleBn}</p>
                        </td>
                        <td className="py-3 px-4 text-slate-300 font-medium">{course?.titleEn || lesson.courseId}</td>
                        <td className="py-3 px-4 uppercase text-emerald-400 font-mono text-[11px]">{lesson.difficulty}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            lesson.isPublished ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' : 'bg-slate-800 text-slate-400'
                          }`}>
                            {lesson.isPublished ? 'Published' : 'Draft'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEditLesson(lesson)}
                              className="p-1 text-slate-400 hover:text-emerald-400"
                              title="Edit lesson"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteLesson(lesson.id)}
                              className="p-1 text-slate-400 hover:text-red-400"
                              title="Delete lesson"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Community Moderation */}
      {activeTab === 'community' && (
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white">Community Posts & Flagged Content</h3>

          {allPosts.length === 0 ? (
            <div className="p-8 text-center bg-[#0F172A] border border-slate-800 rounded-2xl text-slate-400 text-xs">
              No community posts found to moderate.
            </div>
          ) : (
            <div className="space-y-3">
              {allPosts.map(post => (
                <div
                  key={post.id}
                  className={`p-5 rounded-2xl border transition-colors bg-[#0F172A] ${
                    post.isReported ? 'border-red-800/60 bg-red-950/10' : 'border-slate-800'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-xs">{post.userName}</span>
                        <span className="text-[11px] text-slate-400">({post.category})</span>
                        {post.isReported && (
                          <span className="text-[10px] bg-red-950 text-red-400 px-2 py-0.5 rounded font-bold border border-red-800/40">
                            FLAGGED BY USER
                          </span>
                        )}
                      </div>
                      <h4 className="text-sm font-bold text-slate-100 mt-1">{post.title}</h4>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      {post.isReported && (
                        <button
                          onClick={() => handleModeratePost(post.id, 'approved', false)}
                          className="px-3 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800/60 rounded-lg text-xs font-semibold hover:bg-emerald-900/60"
                        >
                          Clear Flag & Approve
                        </button>
                      )}
                      <button
                        onClick={() => handleModeratePost(post.id, 'rejected', true)}
                        className="px-3 py-1 bg-red-950 text-red-400 border border-red-800/60 rounded-lg text-xs font-semibold hover:bg-red-900/60"
                      >
                        Remove Post
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                    {post.content}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Lesson Add/Edit Modal */}
      {isLessonModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-[#0F172A] border border-slate-800 rounded-2xl p-6 shadow-2xl text-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-bold text-white">
                {editingLesson ? 'Edit Lesson' : 'Create New Educational Lesson'}
              </h3>
              <button onClick={() => setIsLessonModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSaveLesson} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Title (English)</label>
                  <input
                    type="text"
                    required
                    value={lessonFormData.titleEn}
                    onChange={e => setLessonFormData({ ...lessonFormData, titleEn: e.target.value })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Title (Bangla)</label>
                  <input
                    type="text"
                    required
                    value={lessonFormData.titleBn}
                    onChange={e => setLessonFormData({ ...lessonFormData, titleBn: e.target.value })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Course</label>
                  <select
                    value={lessonFormData.courseId}
                    onChange={e => setLessonFormData({ ...lessonFormData, courseId: e.target.value })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                  >
                    {courses.map(c => (
                      <option key={c.id} value={c.id}>{c.titleEn}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Difficulty Level</label>
                  <select
                    value={lessonFormData.difficulty}
                    onChange={e => setLessonFormData({ ...lessonFormData, difficulty: e.target.value as any })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                  >
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Summary (English)</label>
                <textarea
                  rows={2}
                  required
                  value={lessonFormData.summaryEn}
                  onChange={e => setLessonFormData({ ...lessonFormData, summaryEn: e.target.value })}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Summary (Bangla)</label>
                <textarea
                  rows={2}
                  required
                  value={lessonFormData.summaryBn}
                  onChange={e => setLessonFormData({ ...lessonFormData, summaryBn: e.target.value })}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Full Content Body (English Markdown)</label>
                <textarea
                  rows={6}
                  required
                  value={lessonFormData.contentEn}
                  onChange={e => setLessonFormData({ ...lessonFormData, contentEn: e.target.value })}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white font-mono text-[11px] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Full Content Body (Bangla Markdown)</label>
                <textarea
                  rows={6}
                  required
                  value={lessonFormData.contentBn}
                  onChange={e => setLessonFormData({ ...lessonFormData, contentBn: e.target.value })}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white font-mono text-[11px] focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Key Takeaways (EN - 1 per line)</label>
                  <textarea
                    rows={3}
                    value={lessonFormData.keyTakeawaysEn}
                    onChange={e => setLessonFormData({ ...lessonFormData, keyTakeawaysEn: e.target.value })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Key Takeaways (BN - 1 per line)</label>
                  <textarea
                    rows={3}
                    value={lessonFormData.keyTakeawaysBn}
                    onChange={e => setLessonFormData({ ...lessonFormData, keyTakeawaysBn: e.target.value })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsLessonModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl"
                >
                  Save & Publish Lesson
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
