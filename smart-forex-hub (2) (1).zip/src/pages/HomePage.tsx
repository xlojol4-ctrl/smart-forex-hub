import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { MarketSessionsClock } from '../components/MarketSessionsClock.tsx';
import { 
  TrendingUp, BookOpen, Calculator, FileText, Bot, Shield, 
  ArrowRight, CheckCircle2, AlertCircle, Compass, Award, Sparkles, BarChart2
} from 'lucide-react';
import type { Course } from '../types/index.ts';

interface HomePageProps {
  courses: Course[];
  setActiveTab: (tab: string) => void;
  setSelectedCourseId?: (id: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ courses, setActiveTab, setSelectedCourseId }) => {
  const { lang, t } = useLanguage();

  // Quick Calculator State for instant homepage trial
  const [balance, setBalance] = useState<number>(5000);
  const [riskPct, setRiskPct] = useState<number>(1);
  const [slPips, setSlPips] = useState<number>(25);
  const [lotResult, setLotResult] = useState<number>(0.2);

  const calculateQuickLot = (b: number, r: number, sl: number) => {
    if (sl <= 0) return;
    const riskDollar = b * (r / 100);
    // standard 1 lot pip value approx $10 on EUR/USD
    const lots = riskDollar / (sl * 10);
    setLotResult(Number(lots.toFixed(2)));
  };

  return (
    <div className="space-y-16 py-6 sm:py-10">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-radial from-[#122244] via-[#0D162C] to-[#0A0F1D] border border-slate-800 p-6 sm:p-12 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/70 border border-emerald-800/40 text-emerald-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Bilingual Forex Education & Tools' : 'বাংলা ও ইংরেজিতে ফরেক্স শিক্ষা'}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {t.heroTitlePrefix}{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
              {t.heroTitleAccent}
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            {t.heroSubtitle}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setActiveTab('learning')}
              className="px-5 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-lg shadow-emerald-500/25 flex items-center gap-2"
            >
              <span>{t.heroCtaCourses}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setActiveTab('calculators')}
              className="px-5 py-3 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-white font-semibold rounded-xl text-sm transition-colors flex items-center gap-2"
            >
              <Calculator className="w-4 h-4 text-emerald-400" />
              <span>{t.heroCtaCalculators}</span>
            </button>

            <button
              onClick={() => setActiveTab('ai')}
              className="px-5 py-3 bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-800/40 text-emerald-300 font-semibold rounded-xl text-sm transition-colors flex items-center gap-2"
            >
              <Bot className="w-4 h-4 text-emerald-400" />
              <span>{t.heroCtaAi}</span>
            </button>
          </div>

          {/* Core Trust Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-800/80">
            <div>
              <p className="text-xl sm:text-2xl font-bold text-white font-mono">17+</p>
              <p className="text-[11px] text-slate-400">{t.statLessons}</p>
            </div>
            <div>
              <p className="text-xl sm:text-2xl font-bold text-emerald-400 font-mono">6</p>
              <p className="text-[11px] text-slate-400">{t.statCalculators}</p>
            </div>
            <div>
              <p className="text-xl sm:text-2xl font-bold text-amber-300 font-mono">100%</p>
              <p className="text-[11px] text-slate-400">{t.statNoSignals}</p>
            </div>
            <div>
              <p className="text-xl sm:text-2xl font-bold text-teal-400 font-mono">EN / BN</p>
              <p className="text-[11px] text-slate-400">{t.statBilingual}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Global Market Sessions Clock */}
      <section>
        <MarketSessionsClock />
      </section>

      {/* Quick Calculator Trial Card */}
      <section className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-md space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-semibold uppercase tracking-wider">
              <Calculator className="w-4 h-4" />
              <span>{lang === 'en' ? 'Interactive Demo' : 'দ্রুত লট সাইজ টেস্ট'}</span>
            </div>
            <h3 className="text-xl font-bold text-white">
              {lang === 'en' ? 'Calculate Exact Lot Size in 5 Seconds' : '৫ সেকেন্ডে সঠিক লট সাইজ নির্ধারণ করুন'}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {lang === 'en'
                ? 'Never guess position sizes. Formula: (Balance × Risk%) ÷ (Stop Loss Pips × $10).'
                : 'মনগড়া লট দিয়ে ঝুঁকি নেবেন না। আপনার ক্যাপিটালের ১% নিয়মে সঠিক লট সাইজ বের করুন।'}
            </p>
          </div>

          <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                {t.calcBalance}
              </label>
              <input
                type="number"
                value={balance}
                onChange={e => {
                  const val = Number(e.target.value);
                  setBalance(val);
                  calculateQuickLot(val, riskPct, slPips);
                }}
                className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                {t.calcRiskPercent}
              </label>
              <input
                type="number"
                step="0.5"
                value={riskPct}
                onChange={e => {
                  const val = Number(e.target.value);
                  setRiskPct(val);
                  calculateQuickLot(balance, val, slPips);
                }}
                className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 font-medium mb-1">
                {t.calcStopLossPips}
              </label>
              <input
                type="number"
                value={slPips}
                onChange={e => {
                  const val = Number(e.target.value);
                  setSlPips(val);
                  calculateQuickLot(balance, riskPct, val);
                }}
                className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="bg-slate-900 border border-emerald-500/30 rounded-xl p-4 text-center min-w-[150px]">
            <p className="text-[11px] text-slate-400">{t.calcResultLotSize}</p>
            <p className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">
              {lotResult} Lots
            </p>
            <p className="text-[10px] text-slate-500 mt-1">
              Risk: ${(balance * (riskPct / 100)).toFixed(0)}
            </p>
          </div>
        </div>
      </section>

      {/* Featured Courses Overview */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-white">
              {lang === 'en' ? 'Structured Forex Curriculum' : 'পরিকল্পিত ফরেক্স পাঠ্যক্রম'}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {lang === 'en'
                ? 'From absolute basics to institutional technicals, risk mathematics, and macroeconomics.'
                : 'বেসিক থেকে প্রাতিষ্ঠানিক টেকনিক্যাল এনালাইসিস, রিস্ক ক্যালকুলেশন ও ম্যাক্রো অর্থনীতি।'}
            </p>
          </div>
          <button
            onClick={() => setActiveTab('learning')}
            className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
          >
            <span>{lang === 'en' ? 'View all courses' : 'সকল কোর্স দেখুন'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {courses.map(course => (
            <div
              key={course.id}
              onClick={() => {
                if (setSelectedCourseId) setSelectedCourseId(course.id);
                setActiveTab('learning');
              }}
              className="bg-[#0F172A] hover:bg-[#131F38] border border-slate-800 hover:border-slate-700 rounded-2xl p-6 transition-all cursor-pointer group shadow-lg flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-semibold uppercase tracking-wider text-emerald-400">
                    {course.difficulty}
                  </span>
                  <span>{course.lessonsCount || 4} Lessons</span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition-colors">
                  {lang === 'en' ? course.titleEn : course.titleBn}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {lang === 'en' ? course.summaryEn : course.summaryBn}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-emerald-400">
                <span>Start Learning</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Platform Pillars */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">
            {lang === 'en' ? 'The 1% Capital Preservation Rule' : '১% ক্যাপিটাল সংরক্ষণ নীতি'}
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            {lang === 'en'
              ? 'Institutional trading is an endurance game. We teach you to calculate stop-loss distances before entering any order so a sequence of losing trades never causes ruin.'
              : 'ফরেক্সে টিকে থাকাটাই প্রধান জয়। আমরা শেখাই কিভাবে প্রতি ট্রেডে ১% এর কম রিস্ক রেখে দীর্ঘমেয়াদে লাভজনক থাকা যায়।'}
          </p>
        </div>

        <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold">
            <AlertCircle className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">
            {lang === 'en' ? 'Strict Zero-Signals Policy' : 'ভুয়া সিগন্যালমুক্ত নীতি'}
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            {lang === 'en'
              ? 'Signal groups create dependencies and eventual account wipeouts. We teach market structure, candlestick math, and economic drivers so you become a self-reliant analyst.'
              : 'সিগন্যাল কেনা বন্ধ করুন। চার্ট রিডিং, ক্যান্ডেলস্টিক ও ইকোনমিক ইভেন্ট বুঝে নিজের সিদ্ধান্তে ট্রেড করার সক্ষমতা অর্জন করুন।'}
          </p>
        </div>

        <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center font-bold">
            <Bot className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">
            {lang === 'en' ? 'Bilingual AI Educational Mentor' : 'দ্বিভাষিক ফরেক্স এআই মেন্টর'}
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            {lang === 'en'
              ? 'Ask any question 24/7 in English or বাংলা. Understand complex concepts like margin calls, multi-timeframe analysis, and Fed interest rate effects with step-by-step clarity.'
              : 'মার্জিন কল, আরএসআই বা এনএফপি নিউজ সংক্রান্ত যেকোনো প্রশ্ন বাংলা বা ইংরেজিতে জিজ্ঞেস করুন এবং তাৎক্ষণিক ব্যাখ্যা পান।'}
          </p>
        </div>
      </section>

      {/* Ready to start CTA Banner */}
      <section className="bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-900/40 rounded-2xl p-8 sm:p-10 text-center space-y-4">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          {lang === 'en' ? 'Begin Your Structured Forex Education Today' : 'আজই আপনার পরিকল্পিত ফরেক্স শিক্ষা শুরু করুন'}
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
          {lang === 'en'
            ? 'Access all structured courses, interactive quizzes, Exness setup tutorials, and your personal trading journal for free.'
            : 'সকল কোর্স, কুইজ, এক্সনেস সেটআপ টিউটোরিয়াল এবং ব্যক্তিগত ট্রেডিং জার্নাল ফ্রিতে ব্যবহার করুন।'}
        </p>
        <div className="pt-2">
          <button
            onClick={() => setActiveTab('learning')}
            className="px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-lg shadow-emerald-500/20"
          >
            {t.heroCtaCourses}
          </button>
        </div>
      </section>
    </div>
  );
};
