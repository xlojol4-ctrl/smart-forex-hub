import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import type { Tutorial } from '../types/index.ts';
import { Compass, ShieldCheck, CheckCircle2, ChevronDown, Lightbulb, ExternalLink } from 'lucide-react';

interface TutorialsPageProps {
  tutorials: Tutorial[];
}

export const TutorialsPage: React.FC<TutorialsPageProps> = ({ tutorials }) => {
  const { lang } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedSteps, setExpandedSteps] = useState<Record<string, number>>({});

  const filtered = tutorials.filter(tut => {
    if (selectedCategory === 'all') return true;
    return tut.category === selectedCategory;
  });

  const toggleStep = (tutId: string, stepIndex: number) => {
    setExpandedSteps(prev => ({
      ...prev,
      [tutId]: prev[tutId] === stepIndex ? -1 : stepIndex
    }));
  };

  return (
    <div className="space-y-8 py-6 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
          <Compass className="w-4 h-4" />
          <span>Step-by-Step Practical Guides</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {lang === 'en' ? 'Trading Tutorials & Platform Setup' : 'ট্রেডিং টিউটোরিয়াল ও প্ল্যাটফর্ম সেটআপ'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          {lang === 'en'
            ? 'Official step-by-step instructions for Exness verification, TradingView layouts, MT4/MT5 terminals, and account security.'
            : 'এক্সনেস ভেরিফিকেশন, ট্রেডিংভিউ চার্ট সেটআপ, মেটাট্রেডার এবং একাউন্ট সিকিউরিটির পূর্ণাঙ্গ গাইড।'}
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex items-center gap-1.5 p-1 bg-[#0F172A] border border-slate-800 rounded-xl w-fit">
        {[
          { id: 'all', label: lang === 'en' ? 'All Guides' : 'সকল গাইড' },
          { id: 'exness', label: 'Exness Setup' },
          { id: 'tradingview', label: 'TradingView' },
          { id: 'security', label: 'Security & 2FA' },
        ].map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              selectedCategory === cat.id
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tutorials List */}
      <div className="space-y-6">
        {filtered.map(tut => (
          <div
            key={tut.id}
            className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
              <div>
                <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
                  {tut.category}
                </span>
                <h2 className="text-lg sm:text-xl font-bold text-white mt-1">
                  {lang === 'en' ? tut.titleEn : tut.titleBn}
                </h2>
              </div>
              <span className="text-xs font-mono text-slate-400 bg-slate-900 px-3 py-1 rounded-full border border-slate-800 shrink-0 self-start sm:self-auto">
                {tut.readTime}
              </span>
            </div>

            {/* Steps Container */}
            <div className="space-y-3">
              {tut.steps.map((step, idx) => {
                const isExpanded = (expandedSteps[tut.id] ?? 0) === idx;
                const stepTitle = lang === 'en' ? step.titleEn : step.titleBn;
                const stepDesc = lang === 'en' ? step.descriptionEn : step.descriptionBn;
                const stepTip = lang === 'en' ? step.tipEn : step.tipBn;

                return (
                  <div
                    key={idx}
                    className="border border-slate-800/80 rounded-xl overflow-hidden bg-[#0A0F1D] transition-colors"
                  >
                    <button
                      type="button"
                      onClick={() => toggleStep(tut.id, idx)}
                      className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-900/60 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-800/60 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs shrink-0">
                          {idx + 1}
                        </span>
                        <span className="text-xs sm:text-sm font-semibold text-slate-200">
                          {stepTitle}
                        </span>
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 transition-transform ${
                          isExpanded ? 'rotate-180 text-emerald-400' : ''
                        }`}
                      />
                    </button>

                    {isExpanded && (
                      <div className="px-5 pb-5 pt-1 space-y-3 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 bg-[#0c1224]/50">
                        <p>{stepDesc}</p>
                        {stepTip && (
                          <div className="p-3 bg-amber-950/20 border border-amber-800/30 rounded-lg flex items-start gap-2 text-xs text-amber-300">
                            <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                            <span><strong>Important Tip:</strong> {stepTip}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
