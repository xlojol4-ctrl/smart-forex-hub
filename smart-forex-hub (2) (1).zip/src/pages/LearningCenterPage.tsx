import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import type { Course, Lesson, QuizQuestion } from '../types/index.ts';
import { 
  BookOpen, Search, Clock, Award, CheckCircle2, 
  ArrowLeft, ArrowRight, HelpCircle, AlertCircle, ChevronRight, RotateCcw
} from 'lucide-react';

interface LearningCenterProps {
  courses: Course[];
  lessons: Lesson[];
  selectedCourseId: string | null;
  setSelectedCourseId: (id: string | null) => void;
}

export const LearningCenterPage: React.FC<LearningCenterProps> = ({
  courses,
  lessons,
  selectedCourseId,
  setSelectedCourseId,
}) => {
  const { lang, t } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);

  // Quiz state
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  // Filter lessons
  const filteredLessons = lessons.filter(lesson => {
    const matchesCourse = selectedCourseId ? lesson.courseId === selectedCourseId : true;
    const matchesDifficulty = selectedDifficulty === 'all' || lesson.difficulty === selectedDifficulty;
    const q = searchQuery.toLowerCase();
    const matchesSearch = 
      lesson.titleEn.toLowerCase().includes(q) ||
      lesson.titleBn.toLowerCase().includes(q) ||
      lesson.summaryEn.toLowerCase().includes(q) ||
      lesson.summaryBn.toLowerCase().includes(q);
    return matchesCourse && matchesDifficulty && matchesSearch;
  });

  const handleSelectLesson = (lesson: Lesson) => {
    setActiveLesson(lesson);
    setQuizAnswers({});
    setQuizSubmitted(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAnswerSelect = (questionId: string, optionIndex: number) => {
    if (quizSubmitted) return;
    setQuizAnswers(prev => ({ ...prev, [questionId]: optionIndex }));
  };

  const handleQuizSubmit = () => {
    setQuizSubmitted(true);
  };

  const calculateScore = (quiz: QuizQuestion[]) => {
    let correct = 0;
    quiz.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswer) correct++;
    });
    return { correct, total: quiz.length };
  };

  // Lesson Detail View
  if (activeLesson) {
    const activeCourse = courses.find(c => c.id === activeLesson.courseId);
    const courseLessons = lessons.filter(l => l.courseId === activeLesson.courseId);
    const currentIndex = courseLessons.findIndex(l => l.id === activeLesson.id);
    const prevLesson = currentIndex > 0 ? courseLessons[currentIndex - 1] : null;
    const nextLesson = currentIndex < courseLessons.length - 1 ? courseLessons[currentIndex + 1] : null;

    return (
      <div className="max-w-4xl mx-auto py-6 sm:py-8 space-y-8">
        {/* Back navigation */}
        <button
          onClick={() => setActiveLesson(null)}
          className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.backToCourses}</span>
        </button>

        {/* Lesson Header */}
        <header className="space-y-3 bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span className="text-emerald-400 font-semibold uppercase tracking-wider">
              {activeLesson.difficulty}
            </span>
            <span>·</span>
            <span>{lang === 'en' ? activeCourse?.titleEn : activeCourse?.titleBn}</span>
            <span>·</span>
            <div className="flex items-center gap-1 text-slate-300 font-mono">
              <Clock className="w-3.5 h-3.5" />
              <span>{activeLesson.readTimeMinutes} {t.readTime}</span>
            </div>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-snug">
            {lang === 'en' ? activeLesson.titleEn : activeLesson.titleBn}
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {lang === 'en' ? activeLesson.summaryEn : activeLesson.summaryBn}
          </p>
        </header>

        {/* Lesson Content Body */}
        <article className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8 text-slate-200 text-xs sm:text-sm leading-relaxed space-y-6">
          <div className="prose prose-invert max-w-none space-y-4">
            {(lang === 'en' ? activeLesson.contentEn : activeLesson.contentBn)
              .split('\n\n')
              .map((block, idx) => {
                if (block.startsWith('### ')) {
                  return (
                    <h3 key={idx} className="text-base sm:text-lg font-bold text-emerald-400 pt-2 border-b border-slate-800/80 pb-1">
                      {block.replace('### ', '')}
                    </h3>
                  );
                }
                if (block.startsWith('> ')) {
                  return (
                    <blockquote key={idx} className="border-l-2 border-emerald-500 pl-4 py-1 text-emerald-200 font-medium bg-emerald-950/20 rounded-r-lg">
                      {block.replace('> ', '')}
                    </blockquote>
                  );
                }
                return (
                  <p key={idx} className="text-slate-300 leading-relaxed whitespace-pre-line">
                    {block}
                  </p>
                );
              })}
          </div>

          {/* Key Takeaways */}
          <div className="mt-8 p-5 bg-[#0a0f1d] border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300 uppercase tracking-wider">
              <Award className="w-4 h-4 text-amber-400" />
              <span>{t.keyTakeaways}</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              {(lang === 'en' ? activeLesson.keyTakeawaysEn : activeLesson.keyTakeawaysBn).map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </article>

        {/* Interactive Quiz */}
        {activeLesson.quiz && activeLesson.quiz.length > 0 && (
          <section className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-emerald-400" />
                <h3 className="text-lg font-bold text-white">{t.takeQuiz}</h3>
              </div>
              {quizSubmitted && (
                <div className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800/40">
                  {t.quizScore}: {calculateScore(activeLesson.quiz).correct} / {activeLesson.quiz.length}
                </div>
              )}
            </div>

            <div className="space-y-6">
              {activeLesson.quiz.map((q, qIndex) => {
                const questionText = lang === 'en' ? q.questionEn : q.questionBn;
                const options = lang === 'en' ? q.optionsEn : q.optionsBn;
                const explanation = lang === 'en' ? q.explanationEn : q.explanationBn;
                const selected = quizAnswers[q.id];
                const isCorrect = selected === q.correctAnswer;

                return (
                  <div key={q.id} className="space-y-3 p-4 bg-[#0a0f1d] rounded-xl border border-slate-800">
                    <p className="text-xs sm:text-sm font-semibold text-white">
                      {qIndex + 1}. {questionText}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {options.map((opt, optIndex) => {
                        let btnStyle = 'border-slate-800 bg-slate-900/60 text-slate-300 hover:bg-slate-800';
                        if (selected === optIndex) {
                          btnStyle = 'border-emerald-500 bg-emerald-950/40 text-emerald-300 font-semibold';
                        }
                        if (quizSubmitted) {
                          if (optIndex === q.correctAnswer) {
                            btnStyle = 'border-emerald-500 bg-emerald-900/50 text-emerald-200 font-bold';
                          } else if (selected === optIndex) {
                            btnStyle = 'border-red-500 bg-red-900/40 text-red-300';
                          }
                        }

                        return (
                          <button
                            key={optIndex}
                            type="button"
                            onClick={() => handleAnswerSelect(q.id, optIndex)}
                            className={`p-3 rounded-lg border text-left text-xs transition-colors flex items-center justify-between ${btnStyle}`}
                          >
                            <span>{opt}</span>
                            {quizSubmitted && optIndex === q.correctAnswer && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {quizSubmitted && (
                      <div className={`mt-2 p-3 rounded-lg text-xs flex items-start gap-2 ${
                        isCorrect ? 'bg-emerald-950/40 text-emerald-300' : 'bg-amber-950/30 text-amber-300'
                      }`}>
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold">{isCorrect ? 'Correct!' : 'Incorrect Answer'}</p>
                          <p className="text-[11px] opacity-90 mt-0.5">{explanation}</p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between pt-2">
              {!quizSubmitted ? (
                <button
                  type="button"
                  onClick={handleQuizSubmit}
                  disabled={Object.keys(quizAnswers).length < activeLesson.quiz.length}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-md shadow-emerald-500/20"
                >
                  Submit Quiz Answers
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setQuizAnswers({});
                    setQuizSubmitted(false);
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake Quiz</span>
                </button>
              )}
            </div>
          </section>
        )}

        {/* Next / Previous Lesson Navigation */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          {prevLesson ? (
            <button
              onClick={() => handleSelectLesson(prevLesson)}
              className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{lang === 'en' ? prevLesson.titleEn : prevLesson.titleBn}</span>
            </button>
          ) : <div />}

          {nextLesson ? (
            <button
              onClick={() => handleSelectLesson(nextLesson)}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-md shadow-emerald-500/20"
            >
              <span>{t.nextLesson}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : <div />}
        </div>
      </div>
    );
  }

  // Catalog View
  return (
    <div className="space-y-8 py-6">
      {/* Header & Search */}
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.navLearning}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            {lang === 'en'
              ? 'Complete syllabus from currency fundamentals to advanced position sizing mathematics.'
              : 'মুদ্রা বাজারের মৌলিক নিয়ম থেকে শুরু করে অ্যাডভান্সড রিস্ক ম্যানেজমেন্টের পূর্ণাঙ্গ সিলেবাস।'}
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-[#0F172A] border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-hidden"
            />
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-[#0F172A] border border-slate-800 rounded-xl">
            {['all', 'beginner', 'intermediate', 'advanced'].map(diff => (
              <button
                key={diff}
                onClick={() => setSelectedDifficulty(diff)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${
                  selectedDifficulty === diff
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {diff === 'all' ? t.filterAll : diff}
              </button>
            ))}
          </div>
        </div>

        {/* Course Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedCourseId(null)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
              selectedCourseId === null
                ? 'bg-slate-800 text-emerald-400 font-semibold'
                : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            {lang === 'en' ? 'All Courses' : 'সকল কোর্স'}
          </button>
          {courses.map(course => (
            <button
              key={course.id}
              onClick={() => setSelectedCourseId(course.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCourseId === course.id
                  ? 'bg-slate-800 text-emerald-400 font-semibold'
                  : 'text-slate-400 hover:text-white bg-slate-900/60'
              }`}
            >
              {lang === 'en' ? course.titleEn : course.titleBn}
            </button>
          ))}
        </div>
      </div>

      {/* Lesson List Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredLessons.map(lesson => {
          const course = courses.find(c => c.id === lesson.courseId);
          return (
            <div
              key={lesson.id}
              onClick={() => handleSelectLesson(lesson)}
              className="bg-[#0F172A] hover:bg-[#131F38] border border-slate-800 hover:border-slate-700 rounded-2xl p-6 transition-all cursor-pointer group shadow-lg flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-semibold uppercase tracking-wider text-emerald-400">
                    {lesson.difficulty}
                  </span>
                  <div className="flex items-center gap-1 font-mono text-[11px] text-slate-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{lesson.readTimeMinutes} {t.readTime}</span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-emerald-300 transition-colors">
                  {lang === 'en' ? lesson.titleEn : lesson.titleBn}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                  {lang === 'en' ? lesson.summaryEn : lesson.summaryBn}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-emerald-400">
                <span className="text-slate-400 text-[11px]">
                  {lang === 'en' ? course?.titleEn : course?.titleBn}
                </span>
                <span className="flex items-center gap-1">
                  Start Lesson
                  <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {filteredLessons.length === 0 && (
        <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-2">
          <BookOpen className="w-8 h-8 text-slate-600 mx-auto" />
          <p className="text-sm font-semibold text-slate-300">No lessons match your search criteria</p>
          <p className="text-xs text-slate-500">Try clearing your search query or selecting a different difficulty level.</p>
        </div>
      )}
    </div>
  );
};
