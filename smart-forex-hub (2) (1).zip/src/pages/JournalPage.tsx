import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import type { TradeRecord } from '../types/index.ts';
import { 
  FileText, Plus, Download, Filter, Trash2, Edit2, 
  TrendingUp, TrendingDown, CheckCircle2, XCircle, AlertCircle, 
  Calendar, Lock, LogIn, ChevronRight
} from 'lucide-react';

export const JournalPage: React.FC = () => {
  const { user, token, openAuthModal, getAuthHeaders } = useAuth();
  const { lang, t } = useLanguage();

  const [trades, setTrades] = useState<TradeRecord[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterPair, setFilterPair] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterStrategy, setFilterStrategy] = useState<string>('all');

  // Trade Modal State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingTrade, setEditingTrade] = useState<TradeRecord | null>(null);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    pair: 'EUR/USD',
    type: 'BUY' as 'BUY' | 'SELL',
    lotSize: 0.1,
    entryPrice: 1.0850,
    stopLoss: 1.0820,
    takeProfit: 1.0910,
    exitPrice: 1.0900,
    status: 'OPEN' as 'OPEN' | 'WIN' | 'LOSS' | 'BREAKEVEN',
    pnl: 0,
    pips: 0,
    strategy: 'Support/Resistance',
    emotion: 'Disciplined' as 'Disciplined' | 'FOMO' | 'Hesitant' | 'Aggressive' | 'Patient',
    notes: '',
  });

  const fetchJournal = async () => {
    if (!token) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const [resTrades, resStats] = await Promise.all([
        fetch('/api/journal', { headers: getAuthHeaders() }),
        fetch('/api/journal/stats', { headers: getAuthHeaders() })
      ]);
      if (resTrades.ok) {
        const data = await resTrades.json();
        setTrades(data.trades || []);
      }
      if (resStats.ok) {
        const statsData = await resStats.json();
        setStats(statsData);
      }
    } catch (e) {
      console.error('Failed to fetch journal:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJournal();
  }, [token]);

  const handleOpenAddModal = () => {
    setEditingTrade(null);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      pair: 'EUR/USD',
      type: 'BUY',
      lotSize: 0.1,
      entryPrice: 1.0850,
      stopLoss: 1.0820,
      takeProfit: 1.0910,
      exitPrice: 1.0900,
      status: 'OPEN',
      pnl: 0,
      pips: 0,
      strategy: 'Breakout & Retest',
      emotion: 'Disciplined',
      notes: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (trade: TradeRecord) => {
    setEditingTrade(trade);
    setFormData({
      date: trade.date,
      pair: trade.pair,
      type: trade.type,
      lotSize: trade.lotSize,
      entryPrice: trade.entryPrice,
      stopLoss: trade.stopLoss,
      takeProfit: trade.takeProfit,
      exitPrice: trade.exitPrice || trade.entryPrice,
      status: trade.status,
      pnl: trade.pnl || 0,
      pips: trade.pips || 0,
      strategy: trade.strategy,
      emotion: trade.emotion || 'Disciplined',
      notes: trade.notes,
    });
    setIsModalOpen(true);
  };

  const handleSaveTrade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    try {
      const url = editingTrade ? `/api/journal/${editingTrade.id}` : '/api/journal';
      const method = editingTrade ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(formData)
      });

      if (res.ok) {
        setIsModalOpen(false);
        fetchJournal();
      }
    } catch (err) {
      console.error('Error saving trade:', err);
    }
  };

  const handleDeleteTrade = async (id: string) => {
    if (!confirm('Are you sure you want to delete this trade record?')) return;
    try {
      const res = await fetch(`/api/journal/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });
      if (res.ok) {
        setTrades(prev => prev.filter(t => t.id !== id));
        fetchJournal();
      }
    } catch (err) {
      console.error('Error deleting trade:', err);
    }
  };

  const exportCSV = () => {
    if (trades.length === 0) return;
    const headers = ['ID', 'Date', 'Pair', 'Type', 'LotSize', 'EntryPrice', 'StopLoss', 'TakeProfit', 'ExitPrice', 'Status', 'PnL', 'Pips', 'Strategy', 'Emotion', 'Notes'];
    const rows = trades.map(t => [
      t.id,
      t.date,
      t.pair,
      t.type,
      t.lotSize,
      t.entryPrice,
      t.stopLoss,
      t.takeProfit,
      t.exitPrice || '',
      t.status,
      t.pnl || 0,
      t.pips || 0,
      `"${t.strategy.replace(/"/g, '""')}"`,
      t.emotion || '',
      `"${t.notes.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SmartForexHub_Journal_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto py-16 text-center space-y-5">
        <div className="w-16 h-16 rounded-2xl bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 flex items-center justify-center mx-auto">
          <Lock className="w-8 h-8" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          {lang === 'en' ? 'Private Authenticated Trading Journal' : 'ব্যক্তিগত সুরক্ষিত ট্রেডিং জার্নাল'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-md mx-auto">
          {lang === 'en'
            ? 'Each user’s trade records and personal strategy notes are strictly isolated and password protected. Sign in or register to record your trades.'
            : 'প্রতিটি ট্রেডারের রেকর্ড এবং নোট সম্পূর্ণ গোপন ও সুরক্ষিত থাকে। জার্নাল ব্যবহার করতে লগইন বা একাউন্ট তৈরি করুন।'}
        </p>
        <button
          onClick={() => openAuthModal('login')}
          className="px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs sm:text-sm transition-colors shadow-lg shadow-emerald-500/20 inline-flex items-center gap-2"
        >
          <LogIn className="w-4 h-4" />
          <span>{t.navSignIn}</span>
        </button>
      </div>
    );
  }

  // Filtered trades
  const filteredTrades = trades.filter(t => {
    if (filterPair !== 'all' && t.pair !== filterPair) return false;
    if (filterStatus !== 'all' && t.status !== filterStatus) return false;
    if (filterStrategy !== 'all' && t.strategy !== filterStrategy) return false;
    return true;
  });

  return (
    <div className="space-y-8 py-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
            <FileText className="w-4 h-4" />
            <span>Private User Journal</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            {t.journalTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            {t.journalSubtitle}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            disabled={trades.length === 0}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-50 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>{t.journalExportCsv}</span>
          </button>

          <button
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-lg shadow-emerald-500/20 flex items-center gap-2"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>{t.journalNewTrade}</span>
          </button>
        </div>
      </div>

      {/* Analytics Summary Banner */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0F172A] border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">{t.journalWinRate}</p>
            <p className="text-xl sm:text-2xl font-black text-emerald-400 font-mono mt-1">
              {stats.winRate}%
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">{stats.winsCount}W / {stats.lossesCount}L</p>
          </div>

          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">{t.journalProfitFactor}</p>
            <p className="text-xl sm:text-2xl font-black text-slate-200 font-mono mt-1">
              {stats.profitFactor}
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">Gross Win / Gross Loss</p>
          </div>

          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">{t.journalNetPnL}</p>
            <p className={`text-xl sm:text-2xl font-black font-mono mt-1 ${stats.netPnL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {stats.netPnL >= 0 ? '+' : ''}${stats.netPnL}
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">{stats.closedTradesCount} Closed Trades</p>
          </div>

          <div>
            <p className="text-[11px] text-slate-400 uppercase font-semibold">{t.journalTotalTrades}</p>
            <p className="text-xl sm:text-2xl font-black text-amber-300 font-mono mt-1">
              {stats.totalTrades}
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">All Time Executions</p>
          </div>
        </div>
      )}

      {/* Filter Controls */}
      <div className="flex flex-wrap items-center gap-2 bg-[#0F172A] p-3 rounded-xl border border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 text-slate-400 font-semibold mr-2">
          <Filter className="w-3.5 h-3.5" />
          <span>Filters:</span>
        </div>

        <select
          value={filterStatus}
          onChange={e => setFilterStatus(e.target.value)}
          className="bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden"
        >
          <option value="all">All Outcomes</option>
          <option value="OPEN">OPEN Only</option>
          <option value="WIN">WIN Only</option>
          <option value="LOSS">LOSS Only</option>
          <option value="BREAKEVEN">BREAKEVEN</option>
        </select>

        <select
          value={filterPair}
          onChange={e => setFilterPair(e.target.value)}
          className="bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden"
        >
          <option value="all">All Pairs</option>
          <option value="EUR/USD">EUR/USD</option>
          <option value="GBP/USD">GBP/USD</option>
          <option value="USD/JPY">USD/JPY</option>
          <option value="XAU/USD">XAU/USD</option>
          <option value="AUD/USD">AUD/USD</option>
        </select>
      </div>

      {/* Trades Table */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-[#0a0f1d]/80 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">{t.journalColDate}</th>
                <th className="py-3 px-4">{t.journalColPair}</th>
                <th className="py-3 px-4">{t.journalColType}</th>
                <th className="py-3 px-4">{t.journalColLots}</th>
                <th className="py-3 px-4">{t.journalColEntry}</th>
                <th className="py-3 px-4">{t.journalColSl}</th>
                <th className="py-3 px-4">{t.journalColTp}</th>
                <th className="py-3 px-4">{t.journalColStatus}</th>
                <th className="py-3 px-4">{t.journalColPnl}</th>
                <th className="py-3 px-4 text-right">{t.journalColActions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredTrades.map(trade => (
                <tr key={trade.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 text-slate-300 whitespace-nowrap">{trade.date}</td>
                  <td className="py-3 px-4 text-white font-bold">{trade.pair}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      trade.type === 'BUY' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' : 'bg-red-950 text-red-400 border border-red-800/40'
                    }`}>
                      {trade.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">{trade.lotSize}</td>
                  <td className="py-3 px-4 text-slate-300">{trade.entryPrice}</td>
                  <td className="py-3 px-4 text-red-400/80">{trade.stopLoss}</td>
                  <td className="py-3 px-4 text-emerald-400/80">{trade.takeProfit}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      trade.status === 'WIN' ? 'bg-emerald-900/40 text-emerald-300' :
                      trade.status === 'LOSS' ? 'bg-red-900/40 text-red-300' :
                      trade.status === 'OPEN' ? 'bg-amber-900/40 text-amber-300' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {trade.status}
                    </span>
                  </td>
                  <td className={`py-3 px-4 font-bold ${
                    (trade.pnl || 0) > 0 ? 'text-emerald-400' : (trade.pnl || 0) < 0 ? 'text-red-400' : 'text-slate-400'
                  }`}>
                    {(trade.pnl || 0) > 0 ? '+' : ''}${trade.pnl || 0}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5 font-sans">
                      <button
                        onClick={() => handleOpenEditModal(trade)}
                        className="p-1 hover:text-emerald-400 text-slate-400 transition-colors"
                        title="Edit trade"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteTrade(trade.id)}
                        className="p-1 hover:text-red-400 text-slate-400 transition-colors"
                        title="Delete trade"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTrades.length === 0 && (
          <div className="py-12 text-center text-slate-400 space-y-2">
            <FileText className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-sm font-semibold text-slate-300">{t.journalNoTrades}</p>
            <p className="text-xs text-slate-500">Click "{t.journalNewTrade}" to log your first execution.</p>
          </div>
        )}
      </div>

      {/* Add / Edit Trade Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="relative w-full max-w-xl bg-[#0F172A] border border-slate-800 rounded-2xl p-6 shadow-2xl text-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-bold text-white">
                {editingTrade ? 'Edit Trade Record' : 'Log New Execution'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveTrade} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Date</label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={e => setFormData({ ...formData, date: e.target.value })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Pair</label>
                  <input
                    type="text"
                    required
                    value={formData.pair}
                    onChange={e => setFormData({ ...formData, pair: e.target.value.toUpperCase() })}
                    placeholder="EUR/USD"
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white uppercase font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Direction</label>
                  <select
                    value={formData.type}
                    onChange={e => setFormData({ ...formData, type: e.target.value as any })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  >
                    <option value="BUY">BUY (Long)</option>
                    <option value="SELL">SELL (Short)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Lot Size</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.lotSize}
                    onChange={e => setFormData({ ...formData, lotSize: Number(e.target.value) })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Entry Price</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={formData.entryPrice}
                    onChange={e => setFormData({ ...formData, entryPrice: Number(e.target.value) })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Stop Loss</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={formData.stopLoss}
                    onChange={e => setFormData({ ...formData, stopLoss: Number(e.target.value) })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Take Profit</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={formData.takeProfit}
                    onChange={e => setFormData({ ...formData, takeProfit: Number(e.target.value) })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Status</label>
                  <select
                    value={formData.status}
                    onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  >
                    <option value="OPEN">OPEN</option>
                    <option value="WIN">WIN</option>
                    <option value="LOSS">LOSS</option>
                    <option value="BREAKEVEN">BREAKEVEN</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">P&L ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.pnl}
                    onChange={e => setFormData({ ...formData, pnl: Number(e.target.value) })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Strategy</label>
                  <select
                    value={formData.strategy}
                    onChange={e => setFormData({ ...formData, strategy: e.target.value })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  >
                    <option value="Breakout & Retest">Breakout & Retest</option>
                    <option value="Support/Resistance">Support/Resistance</option>
                    <option value="Trend Following EMA">Trend Following EMA</option>
                    <option value="Candlestick Pin Bar">Candlestick Pin Bar</option>
                    <option value="News Reaction">News Reaction</option>
                    <option value="Discretionary">Discretionary</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Emotional Mindset</label>
                  <select
                    value={formData.emotion}
                    onChange={e => setFormData({ ...formData, emotion: e.target.value as any })}
                    className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  >
                    <option value="Disciplined">Disciplined (Planned)</option>
                    <option value="Patient">Patient (Waited for trigger)</option>
                    <option value="FOMO">FOMO (Chased green candle)</option>
                    <option value="Hesitant">Hesitant (Entered late)</option>
                    <option value="Aggressive">Aggressive (Revenge trade)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Trade Notes & Lessons Learned</label>
                <textarea
                  rows={3}
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Why did you take this setup? Did you follow your 1% risk rule?"
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2.5 text-white focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl"
                >
                  Save Trade
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
