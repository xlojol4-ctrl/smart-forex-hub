import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { Calculator, AlertTriangle, Info, Check, RefreshCw, HelpCircle } from 'lucide-react';

const PAIRS = [
  { code: 'EUR/USD', pipDecimal: 4, pipValueStd: 10.0, currentPrice: 1.0850 },
  { code: 'GBP/USD', pipDecimal: 4, pipValueStd: 10.0, currentPrice: 1.2920 },
  { code: 'USD/JPY', pipDecimal: 2, pipValueStd: 6.65, currentPrice: 150.30 },
  { code: 'USD/CHF', pipDecimal: 4, pipValueStd: 11.20, currentPrice: 0.8920 },
  { code: 'AUD/USD', pipDecimal: 4, pipValueStd: 10.0, currentPrice: 0.6650 },
  { code: 'USD/CAD', pipDecimal: 4, pipValueStd: 7.30, currentPrice: 1.3700 },
  { code: 'EUR/GBP', pipDecimal: 4, pipValueStd: 12.90, currentPrice: 0.8400 },
  { code: 'GBP/JPY', pipDecimal: 2, pipValueStd: 6.65, currentPrice: 194.20 },
  { code: 'XAU/USD (Gold)', pipDecimal: 2, pipValueStd: 10.0, currentPrice: 2650.00 },
];

export const CalculatorsPage: React.FC = () => {
  const { lang, t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'position' | 'risk_sl' | 'pip' | 'margin' | 'rr' | 'pnl'>('position');

  // Calculator 1: Position Size
  const [posBalance, setPosBalance] = useState<number>(10000);
  const [posRiskPct, setPosRiskPct] = useState<number>(1);
  const [posSlPips, setPosSlPips] = useState<number>(20);
  const [posPair, setPosPair] = useState<string>('EUR/USD');

  // Calculator 2: Risk % & Stop Loss Price
  const [riskBalance, setRiskBalance] = useState<number>(5000);
  const [riskLots, setRiskLots] = useState<number>(0.25);
  const [riskEntry, setRiskEntry] = useState<number>(1.0850);
  const [riskDirection, setRiskDirection] = useState<'BUY' | 'SELL'>('BUY');
  const [riskMaxDollar, setRiskMaxDollar] = useState<number>(50);

  // Calculator 3: Pip Value
  const [pipLots, setPipLots] = useState<number>(1.0);
  const [pipPair, setPipPair] = useState<string>('EUR/USD');

  // Calculator 4: Margin Calculator
  const [marginLots, setMarginLots] = useState<number>(1.0);
  const [marginLeverage, setMarginLeverage] = useState<number>(100);
  const [marginPair, setMarginPair] = useState<string>('EUR/USD');

  // Calculator 5: Risk to Reward (R:R)
  const [rrEntry, setRrEntry] = useState<number>(1.0850);
  const [rrSl, setRrSl] = useState<number>(1.0820);
  const [rrTp, setRrTp] = useState<number>(1.0910);
  const [rrLots, setRrLots] = useState<number>(0.5);

  // Calculator 6: Profit / Loss Estimator
  const [pnlEntry, setPnlEntry] = useState<number>(1.0850);
  const [pnlExit, setPnlExit] = useState<number>(1.0895);
  const [pnlLots, setPnlLots] = useState<number>(0.5);
  const [pnlDirection, setPnlDirection] = useState<'BUY' | 'SELL'>('BUY');
  const [pnlPair, setPnlPair] = useState<string>('EUR/USD');

  // Calculation logic
  const selectedPosPairData = PAIRS.find(p => p.code === posPair) || PAIRS[0];
  const posRiskAmount = posBalance * (posRiskPct / 100);
  const posLotsCalculated = posSlPips > 0 
    ? posRiskAmount / (posSlPips * selectedPosPairData.pipValueStd) 
    : 0;

  // Pip value calc
  const selectedPipPairData = PAIRS.find(p => p.code === pipPair) || PAIRS[0];
  const calculatedPipValue = pipLots * selectedPipPairData.pipValueStd;

  // Margin calc
  const selectedMarginPairData = PAIRS.find(p => p.code === marginPair) || PAIRS[0];
  // 1 standard lot = 100,000 units of base currency
  const baseUnits = marginLots * 100000;
  // approximate in USD
  const tradeValueUsd = baseUnits * (marginPair.includes('EUR') ? 1.085 : marginPair.includes('GBP') ? 1.292 : 1.0);
  const requiredMargin = tradeValueUsd / marginLeverage;

  // R:R calc
  const rrRiskDist = Math.abs(rrEntry - rrSl);
  const rrRewardDist = Math.abs(rrTp - rrEntry);
  const rrRatio = rrRiskDist > 0 ? (rrRewardDist / rrRiskDist).toFixed(2) : '0';
  const rrPipsRisk = Math.round(rrRiskDist * 10000);
  const rrPipsReward = Math.round(rrRewardDist * 10000);

  // Risk % & SL price calc
  const slPipsAllowed = riskLots > 0 ? riskMaxDollar / (riskLots * 10) : 0;
  const calculatedSlPrice = riskDirection === 'BUY' 
    ? riskEntry - (slPipsAllowed * 0.0001) 
    : riskEntry + (slPipsAllowed * 0.0001);

  // PnL Estimator calc
  const pnlPairData = PAIRS.find(p => p.code === pnlPair) || PAIRS[0];
  const pnlPriceDiff = pnlDirection === 'BUY' ? (pnlExit - pnlEntry) : (pnlEntry - pnlExit);
  const pnlPips = pnlPairData.pipDecimal === 2 
    ? pnlPriceDiff * 100 
    : pnlPriceDiff * 10000;
  const estimatedProfit = pnlPips * (pnlLots * pnlPairData.pipValueStd);

  return (
    <div className="space-y-8 py-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
          <Calculator className="w-4 h-4" />
          <span>Institutional Mathematical Utilities</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {t.calcTitle}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          {t.calcSubtitle}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#0F172A] border border-slate-800 rounded-xl overflow-x-auto scrollbar-none">
        {[
          { id: 'position', label: t.calcTabPosition },
          { id: 'risk_sl', label: t.calcTabRiskSl },
          { id: 'pip', label: t.calcTabPip },
          { id: 'margin', label: t.calcTabMargin },
          { id: 'rr', label: t.calcTabRr },
          { id: 'pnl', label: t.calcTabProfit },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Active Calculator Box */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-8 shadow-xl">
        {/* Tab 1: Position Size */}
        {activeTab === 'position' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white">{t.calcTabPosition}</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Calculate the mathematically exact lot size based on account balance and stop loss distance.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">{t.calcCurrencyPair}</label>
                <select
                  value={posPair}
                  onChange={e => setPosPair(e.target.value)}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-emerald-500 focus:outline-hidden"
                >
                  {PAIRS.map(p => (
                    <option key={p.code} value={p.code}>{p.code}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">{t.calcBalance}</label>
                <input
                  type="number"
                  value={posBalance}
                  onChange={e => setPosBalance(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">{t.calcRiskPercent}</label>
                <input
                  type="number"
                  step="0.5"
                  value={posRiskPct}
                  onChange={e => setPosRiskPct(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">{t.calcStopLossPips}</label>
                <input
                  type="number"
                  value={posSlPips}
                  onChange={e => setPosSlPips(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            {/* Results Display */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 bg-[#0a0f1d] border border-slate-800 rounded-xl">
              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">{t.calcResultLotSize}</p>
                <p className="text-2xl font-black text-emerald-400 font-mono mt-1">
                  {posLotsCalculated.toFixed(2)} Lots
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Units: {(posLotsCalculated * 100000).toLocaleString()}</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">{t.calcResultRiskAmount}</p>
                <p className="text-2xl font-black text-amber-300 font-mono mt-1">
                  ${posRiskAmount.toFixed(2)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">{posRiskPct}% of ${posBalance.toLocaleString()}</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Standard Pip Value</p>
                <p className="text-2xl font-black text-slate-200 font-mono mt-1">
                  ${selectedPosPairData.pipValueStd.toFixed(2)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Per 1.00 standard lot</p>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 bg-slate-900/40 p-3 rounded-lg border border-slate-800">
              <strong>Formula:</strong> Lot Size = (Account Balance × Risk %) ÷ (Stop Loss Pips × Pip Value per standard lot).
            </div>
          </div>
        )}

        {/* Tab 2: Risk % & Stop Loss Price */}
        {activeTab === 'risk_sl' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white">{t.calcTabRiskSl}</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Calculate the exact Stop Loss price level where your predetermined maximum dollar risk is reached.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Trade Direction</label>
                <div className="grid grid-cols-2 gap-1 p-1 bg-[#0a0f1d] border border-slate-700 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setRiskDirection('BUY')}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      riskDirection === 'BUY' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400'
                    }`}
                  >
                    BUY (Long)
                  </button>
                  <button
                    type="button"
                    onClick={() => setRiskDirection('SELL')}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      riskDirection === 'SELL' ? 'bg-red-500 text-white' : 'text-slate-400'
                    }`}
                  >
                    SELL (Short)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Entry Price</label>
                <input
                  type="number"
                  step="0.0001"
                  value={riskEntry}
                  onChange={e => setRiskEntry(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Planned Lot Size</label>
                <input
                  type="number"
                  step="0.01"
                  value={riskLots}
                  onChange={e => setRiskLots(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Max Risk Cap ($)</label>
                <input
                  type="number"
                  value={riskMaxDollar}
                  onChange={e => setRiskMaxDollar(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-5 bg-[#0a0f1d] border border-slate-800 rounded-xl">
              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Exact Stop Loss Price</p>
                <p className="text-2xl font-black text-red-400 font-mono mt-1">
                  {calculatedSlPrice.toFixed(4)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Place order SL at this price</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Allowed Stop Distance</p>
                <p className="text-2xl font-black text-amber-300 font-mono mt-1">
                  {slPipsAllowed.toFixed(1)} Pips
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Based on ${riskMaxDollar} maximum loss</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Pip Value */}
        {activeTab === 'pip' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white">{t.calcTabPip}</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Understand the exact dollar equivalent of a 1-pip movement for any lot size and currency.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">{t.calcCurrencyPair}</label>
                <select
                  value={pipPair}
                  onChange={e => setPipPair(e.target.value)}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-emerald-500 focus:outline-hidden"
                >
                  {PAIRS.map(p => (
                    <option key={p.code} value={p.code}>{p.code}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Trade Lot Size</label>
                <input
                  type="number"
                  step="0.01"
                  value={pipLots}
                  onChange={e => setPipLots(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 bg-[#0a0f1d] border border-slate-800 rounded-xl">
              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Pip Value (1 Pip)</p>
                <p className="text-2xl font-black text-emerald-400 font-mono mt-1">
                  ${calculatedPipValue.toFixed(2)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Per {pipLots} lot(s)</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">10 Pips Move</p>
                <p className="text-2xl font-black text-slate-200 font-mono mt-1">
                  ${(calculatedPipValue * 10).toFixed(2)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Financial impact</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">50 Pips Move</p>
                <p className="text-2xl font-black text-amber-300 font-mono mt-1">
                  ${(calculatedPipValue * 50).toFixed(2)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Financial impact</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Margin Calculator */}
        {activeTab === 'margin' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white">{t.calcTabMargin}</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Calculate how much cash margin collateral your broker locks to hold a trade open.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">{t.calcCurrencyPair}</label>
                <select
                  value={marginPair}
                  onChange={e => setMarginPair(e.target.value)}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-emerald-500 focus:outline-hidden"
                >
                  {PAIRS.map(p => (
                    <option key={p.code} value={p.code}>{p.code}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Trade Lot Size</label>
                <input
                  type="number"
                  step="0.05"
                  value={marginLots}
                  onChange={e => setMarginLots(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Account Leverage</label>
                <select
                  value={marginLeverage}
                  onChange={e => setMarginLeverage(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-emerald-500 focus:outline-hidden"
                >
                  <option value={50}>1:50 (Low Leverage)</option>
                  <option value={100}>1:100 (Standard Recommended)</option>
                  <option value={200}>1:200 (Moderate)</option>
                  <option value={500}>1:500 (High Risk)</option>
                  <option value={1000}>1:1000 (Extreme Risk)</option>
                  <option value={2000}>1:2000 (Unlimited / Exness Pro)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-5 bg-[#0a0f1d] border border-slate-800 rounded-xl">
              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Required Cash Margin</p>
                <p className="text-2xl font-black text-emerald-400 font-mono mt-1">
                  ${requiredMargin.toFixed(2)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Locked collateral during open trade</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Total Position Notional Value</p>
                <p className="text-2xl font-black text-slate-200 font-mono mt-1">
                  ${tradeValueUsd.toLocaleString()}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Total contract value controlled</p>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 bg-slate-900/40 p-3 rounded-lg border border-slate-800">
              <strong>Formula:</strong> Required Margin = (Lot Size × 100,000 × Contract Price) ÷ Leverage.
            </div>
          </div>
        )}

        {/* Tab 5: Risk to Reward */}
        {activeTab === 'rr' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white">{t.calcTabRr}</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Calculate Risk-to-Reward ratio to ensure your potential reward justifies the risk before execution.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Entry Price</label>
                <input
                  type="number"
                  step="0.0001"
                  value={rrEntry}
                  onChange={e => setRrEntry(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Stop Loss Price</label>
                <input
                  type="number"
                  step="0.0001"
                  value={rrSl}
                  onChange={e => setRrSl(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Take Profit Price</label>
                <input
                  type="number"
                  step="0.0001"
                  value={rrTp}
                  onChange={e => setRrTp(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Lot Size</label>
                <input
                  type="number"
                  step="0.01"
                  value={rrLots}
                  onChange={e => setRrLots(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 bg-[#0a0f1d] border border-slate-800 rounded-xl">
              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Risk : Reward Ratio</p>
                <p className={`text-2xl font-black font-mono mt-1 ${Number(rrRatio) >= 2 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  1 : {rrRatio}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  {Number(rrRatio) >= 2 ? '✓ Meets institutional standard' : '⚠️ Sub-optimal R:R (< 1:2)'}
                </p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Potential Loss</p>
                <p className="text-2xl font-black text-red-400 font-mono mt-1">
                  -${(rrPipsRisk * rrLots * 10).toFixed(0)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">{rrPipsRisk} Pips at risk</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Potential Gain</p>
                <p className="text-2xl font-black text-emerald-400 font-mono mt-1">
                  +${(rrPipsReward * rrLots * 10).toFixed(0)}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">{rrPipsReward} Pips target</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 6: Profit/Loss Estimator */}
        {activeTab === 'pnl' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white">{t.calcTabProfit}</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Simulate potential trade outcome before closing or modifying an open order.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">{t.calcCurrencyPair}</label>
                <select
                  value={pnlPair}
                  onChange={e => setPnlPair(e.target.value)}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-emerald-500 focus:outline-hidden"
                >
                  {PAIRS.map(p => (
                    <option key={p.code} value={p.code}>{p.code}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Direction</label>
                <div className="grid grid-cols-2 gap-1 p-1 bg-[#0a0f1d] border border-slate-700 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setPnlDirection('BUY')}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      pnlDirection === 'BUY' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400'
                    }`}
                  >
                    BUY
                  </button>
                  <button
                    type="button"
                    onClick={() => setPnlDirection('SELL')}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      pnlDirection === 'SELL' ? 'bg-red-500 text-white' : 'text-slate-400'
                    }`}
                  >
                    SELL
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Lot Size</label>
                <input
                  type="number"
                  step="0.05"
                  value={pnlLots}
                  onChange={e => setPnlLots(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Entry Price</label>
                <input
                  type="number"
                  step="0.0001"
                  value={pnlEntry}
                  onChange={e => setPnlEntry(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Exit Price</label>
                <input
                  type="number"
                  step="0.0001"
                  value={pnlExit}
                  onChange={e => setPnlExit(Number(e.target.value))}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-5 bg-[#0a0f1d] border border-slate-800 rounded-xl">
              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Estimated Net Outcome</p>
                <p className={`text-2xl font-black font-mono mt-1 ${estimatedProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {estimatedProfit >= 0 ? '+' : ''}${estimatedProfit.toFixed(2)} USD
                </p>
                <p className="text-[11px] text-slate-500 mt-1">Gross estimate before broker commission & swap</p>
              </div>

              <div>
                <p className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Price Delta (Pips)</p>
                <p className={`text-2xl font-black font-mono mt-1 ${pnlPips >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {pnlPips >= 0 ? '+' : ''}{pnlPips.toFixed(1)} Pips
                </p>
                <p className="text-[11px] text-slate-500 mt-1">{pnlDirection} trade on {pnlPair}</p>
              </div>
            </div>
          </div>
        )}

        {/* Disclaimer Callout */}
        <div className="p-4 bg-amber-950/20 border border-amber-900/30 rounded-xl flex items-start gap-2.5 text-xs text-amber-300/90 leading-relaxed">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>{t.calcDisclaimer}</p>
        </div>
      </div>
    </div>
  );
};
