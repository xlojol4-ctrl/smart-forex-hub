import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import type { AiChatMessage } from '../types/index.ts';
import { Bot, Send, User, Sparkles, AlertCircle, RefreshCw, HelpCircle } from 'lucide-react';

export const AiAssistantPage: React.FC = () => {
  const { lang, t } = useLanguage();

  const [messages, setMessages] = useState<AiChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'assistant',
      text: lang === 'en'
        ? 'Hello! I am your Smart Forex Hub Educational AI Mentor. I specialize in explaining currency pair mechanics, technical chart patterns, risk management rules, and trading psychology. I can answer fluently in English or বাংলা (Bengali). How can I help your learning today?'
        : 'আসসালামু আলাইকুম / নমস্কার! আমি আপনার স্মার্ট ফরেক্স হাব এআই মেন্টর। ফরেক্স বেসিক, কারেন্সি পেয়ার, চার্ট প্যাটার্ন, ১% রিস্ক রুল এবং ট্রেডিং সাইকোলজি নিয়ে যেকোনো প্রশ্ন করতে পারেন। আমি বাংলা ও ইংরেজিতে ব্যাখ্যা করতে পারি। আজ আপনি কি শিখতে চান?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const quickPrompts = lang === 'en' ? [
    'How does 1:100 leverage work with margin?',
    'Explain the 1% risk rule on EUR/USD',
    'What is the difference between a Pin Bar and Doji?',
    'Why is Non-Farm Payrolls (NFP) so volatile?',
    'How do I overcome revenge trading after a loss?'
  ] : [
    'লিভারেজ ১:১০০ কিভাবে কাজ করে?',
    'EUR/USD পেয়ারে ১% রিস্ক রুল কিভাবে প্রয়োগ করব?',
    'পিন বার (Pin Bar) এবং ডোজি (Doji) এর মধ্যে পার্থক্য কি?',
    'এনএফপি (NFP) নিউজের সময় মার্কেট কেন এত বেশি মুভ করে?',
    'ট্রেডে লস হওয়ার পর রিভেঞ্জ ট্রেডিং থেকে বাঁচব কিভাবে?'
  ];

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    const userMsg: AiChatMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      // Build conversation history for context
      const historyPayload = messages.map(m => ({
        sender: m.sender,
        text: m.text
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: query,
          history: historyPayload
        })
      });

      const data = await res.json();
      const botText = res.ok ? data.response : (data.error || 'Failed to receive mentor explanation.');

      const botMsg: AiChatMessage = {
        id: 'bot_' + Date.now(),
        sender: 'assistant',
        text: botText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (e: any) {
      console.error('AI chat error:', e);
      setMessages(prev => [
        ...prev,
        {
          id: 'bot_err_' + Date.now(),
          sender: 'assistant',
          text: 'The AI Assistant encountered a connection issue. Please verify your connection or try again.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'msg-welcome-reset',
        sender: 'assistant',
        text: lang === 'en'
          ? 'Conversation cleared. What Forex concept would you like to explore next?'
          : 'কথোপকথন রিসেট করা হয়েছে। কোন ফরেক্স বিষয়টি আপনি জানতে চান?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }
    ]);
  };

  return (
    <div className="max-w-4xl mx-auto py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
            <Bot className="w-4 h-4" />
            <span>Dedicated Educational Intelligence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            {t.aiTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            {t.aiSubtitle}
          </p>
        </div>

        <button
          onClick={handleClearChat}
          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Clear Chat</span>
        </button>
      </div>

      {/* Strict Compliance Warning */}
      <div className="p-3.5 bg-emerald-950/20 border border-emerald-900/30 rounded-xl flex items-start gap-2.5 text-xs text-emerald-300/90 leading-relaxed">
        <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <p>{t.aiDisclaimer}</p>
      </div>

      {/* Suggested Quick Prompts */}
      <div className="space-y-2">
        <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
          <HelpCircle className="w-3.5 h-3.5 text-emerald-400" />
          <span>{t.aiQuickPrompts}:</span>
        </p>
        <div className="flex flex-wrap gap-2">
          {quickPrompts.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="px-3 py-1.5 rounded-lg border border-slate-800 bg-[#0F172A] hover:bg-[#131F38] hover:border-slate-700 text-xs text-slate-300 transition-colors text-left"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Box */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-4 sm:p-6 h-[480px] overflow-y-auto space-y-4 shadow-xl">
        {messages.map(msg => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-emerald-600 text-slate-950 font-medium rounded-tr-xs shadow-md'
                    : 'bg-[#0a0f1d] border border-slate-800 text-slate-200 rounded-tl-xs whitespace-pre-line'
                }`}
              >
                <div className="flex items-center justify-between gap-3 mb-1 text-[10px] opacity-75 font-mono">
                  <span>{isUser ? 'You' : 'Smart Forex AI'}</span>
                  <span>{msg.timestamp}</span>
                </div>
                <div className="prose prose-invert max-w-none">
                  {msg.text}
                </div>
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center shrink-0 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-3 items-center text-xs text-slate-400 bg-[#0a0f1d] border border-slate-800 p-3 rounded-2xl w-fit">
            <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
            <span>Analyzing concept & formulating educational guidance...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <form
        onSubmit={e => {
          e.preventDefault();
          handleSend();
        }}
        className="flex gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={t.aiPlaceholder}
          disabled={loading}
          className="flex-1 bg-[#0F172A] border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-hidden transition-colors"
        />

        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="px-5 py-3 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-bold rounded-xl text-xs sm:text-sm transition-all shadow-md shadow-emerald-500/20 flex items-center gap-1.5 shrink-0"
        >
          <span>{t.aiSend}</span>
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
