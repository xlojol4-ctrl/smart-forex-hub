import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import type { ResourceItem } from '../types/index.ts';
import { Award, CheckSquare, Search, CheckCircle2, FileText, Printer, Sparkles } from 'lucide-react';

interface ResourcesPageProps {
  resources: ResourceItem[];
}

export const ResourcesPage: React.FC<ResourcesPageProps> = ({ resources }) => {
  const { lang } = useLanguage();
  const [selectedTab, setSelectedTab] = useState<'all' | 'checklist' | 'cheatsheet' | 'glossary'>('all');
  const [glossarySearch, setGlossarySearch] = useState('');

  // Interactive Checklist State
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({});

  const checklistPoints = [
    { en: 'Higher Timeframe Trend identified on Daily & 4H charts', bn: 'ডেইলি এবং ৪ ঘণ্টার চার্টে মূল ট্রেন্ড নিশ্চিত করা হয়েছে' },
    { en: 'Key Support / Resistance or Order Block marked', bn: 'সাপোর্ট বা রেজিস্ট্যান্স এলাকা সুস্পষ্টভাবে চিহ্নিত' },
    { en: 'No red-folder high-impact economic news scheduled within 30 minutes', bn: 'আগামী ৩০ মিনিটে কোনো হাই-ইমপ্যাক্ট রেড ফোল্ডার নিউজ নেই' },
    { en: 'Clear price action pattern formed (Pin bar, Engulfing, Breakout Retest)', bn: 'স্পষ্ট প্রাইস অ্যাকশন ক্যান্ডেলস্টিক প্যাটার্ন বা রিটেস্ট গঠিত হয়েছে' },
    { en: 'Stop Loss placed at logical technical invalidation level (not random pips)', bn: 'স্টপ লস টেকনিক্যাল কাঠামোর বাইরে যৌক্তিক স্থানে নির্ধারণ করা' },
    { en: 'Position size calculated strictly at or below 1% to 2% of account equity', bn: 'লট সাইজ মোট অ্যাকাউন্টের ১% থেকে ২% ঝুঁকির মধ্যে হিসেবকৃত' },
    { en: 'Minimum 1:2 Risk-to-Reward ratio available to realistic target', bn: 'টার্গেট পর্যন্ত ন্যূনতম ১:২ রিস্ক-টু-রিওয়ার্ড রেশিও বিদ্যমান' },
    { en: 'Mentally calm and prepared to accept the loss if the setup fails', bn: 'ট্রেড ব্যর্থ হলে স্টপ লস শান্ত মনে মেনে নেওয়ার মানসিক প্রস্তুতি আছে' },
  ];

  const handleToggleChecklist = (index: number) => {
    setCheckedItems(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const completedCount = Object.values(checkedItems).filter(Boolean).length;
  const readinessPct = Math.round((completedCount / checklistPoints.length) * 100);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 py-6 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
            <Award className="w-4 h-4" />
            <span>Original Educational Materials</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            {lang === 'en' ? 'Free Study Resources & Checklists' : 'বিনামূল্যে শিক্ষামূলক রিসোর্স ও চেকলিস্ট'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            {lang === 'en'
              ? 'Printable reference cheat sheets, execution verification checklists, and master glossaries.'
              : 'প্রিন্টযোগ্য চিট শিট, ট্রেড এক্সিকিউশন চেকলিস্ট এবং সম্পূর্ণ ফরেক্স শব্দকোষ।'}
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-2 self-start sm:self-auto transition-colors"
        >
          <Printer className="w-4 h-4 text-emerald-400" />
          <span>Print / Save PDF</span>
        </button>
      </div>

      {/* Interactive 20-Point Checklist Widget */}
      <section className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
              <CheckSquare className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                {lang === 'en' ? 'Live Pre-Flight Execution Checklist' : 'ট্রেড নেওয়ার আগের লাইভ চেকলিস্ট'}
              </h2>
              <p className="text-xs text-slate-400">
                {lang === 'en' ? 'Tick every rule before placing any live order on MT4/MT5.' : 'অর্ডার প্লেস করার আগে নিয়মগুলো যাচাই করুন।'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-[11px] text-slate-400 font-medium">Readiness Score</p>
              <p className={`text-base font-extrabold font-mono ${readinessPct === 100 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {readinessPct}% Complete
              </p>
            </div>
            <div className="w-12 h-12 rounded-full border-2 border-slate-700 flex items-center justify-center text-xs font-bold font-mono">
              {completedCount}/{checklistPoints.length}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {checklistPoints.map((point, idx) => {
            const isChecked = !!checkedItems[idx];
            return (
              <div
                key={idx}
                onClick={() => handleToggleChecklist(idx)}
                className={`p-3.5 rounded-xl border cursor-pointer select-none transition-all flex items-start gap-3 ${
                  isChecked
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
                    : 'bg-[#0a0f1d] border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className={`w-5 h-5 rounded-md flex items-center justify-center mt-0.5 shrink-0 transition-colors ${
                  isChecked ? 'bg-emerald-500 text-slate-950' : 'border border-slate-600 bg-slate-900'
                }`}>
                  {isChecked && <CheckCircle2 className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
                <span className="text-xs font-medium leading-relaxed">
                  {lang === 'en' ? point.en : point.bn}
                </span>
              </div>
            );
          })}
        </div>

        {readinessPct === 100 ? (
          <div className="p-3 bg-emerald-950/40 border border-emerald-800/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>All execution criteria verified. Maintain discipline and honor your Stop Loss without moving it.</span>
          </div>
        ) : (
          <p className="text-[11px] text-slate-500 italic">
            Never force a setup if key conditions (like Risk ≤ 1% or minimum 1:2 R:R) are unmet.
          </p>
        )}
      </section>

      {/* Candlestick & Cheat Sheets */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {resources.map(res => (
          <div
            key={res.id}
            className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="text-emerald-400 font-semibold uppercase tracking-wider">
                  {res.category}
                </span>
                <span className="font-mono bg-slate-900 px-2.5 py-0.5 rounded border border-slate-800">
                  {res.format}
                </span>
              </div>

              <h3 className="text-lg font-bold text-white">
                {lang === 'en' ? res.titleEn : res.titleBn}
              </h3>

              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'en' ? res.descriptionEn : res.descriptionBn}
              </p>

              {res.contentEn && (
                <div className="p-4 bg-[#0a0f1d] border border-slate-800 rounded-xl text-xs text-slate-300 whitespace-pre-line leading-relaxed font-sans">
                  {lang === 'en' ? res.contentEn : res.contentBn}
                </div>
              )}
            </div>

            <div className="pt-2">
              <button
                onClick={handlePrint}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <FileText className="w-3.5 h-3.5 text-emerald-400" />
                <span>Save Reference Copy</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
