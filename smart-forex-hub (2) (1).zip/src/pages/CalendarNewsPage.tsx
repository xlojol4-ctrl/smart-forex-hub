import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { MarketSessionsClock } from '../components/MarketSessionsClock.tsx';
import type { EconomicEvent } from '../types/index.ts';
import { Globe2, Calendar, AlertCircle, Clock, Filter, Info, ShieldAlert } from 'lucide-react';

interface CalendarNewsPageProps {
  events: EconomicEvent[];
}

export const CalendarNewsPage: React.FC<CalendarNewsPageProps> = ({ events }) => {
  const { lang } = useLanguage();
  const [filterImpact, setFilterImpact] = useState<string>('all');
  const [filterCurrency, setFilterCurrency] = useState<string>('all');

  const filteredEvents = events.filter(ev => {
    if (filterImpact !== 'all' && ev.impact !== filterImpact) return false;
    if (filterCurrency !== 'all' && ev.currency !== filterCurrency) return false;
    return true;
  });

  return (
    <div className="space-y-8 py-6 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
          <Globe2 className="w-4 h-4" />
          <span>Macroeconomic Schedule & News</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {lang === 'en' ? 'Forex Economic Calendar & Market Events' : 'ফরেক্স ইকোনমিক ক্যালেন্ডার ও মার্কেট ইভেন্ট'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          {lang === 'en'
            ? 'Track high-impact macroeconomic releases, central bank interest rate decisions, and inflation reports.'
            : 'সেন্ট্রাল ব্যাংক সুদের হার, মুদ্রাস্ফীতি (CPI) এবং এনএফপি খবরের সময়সূচী ও প্রভাব বিশ্লেষণ।'}
        </p>
      </div>

      {/* Global Market Session Status */}
      <MarketSessionsClock />

      {/* Honesty & Data Transparency Notice */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl flex items-start gap-3 text-xs text-slate-300">
        <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-white">
            {lang === 'en' ? 'Market Data Transparency & Trading Advice' : 'মার্কেট ডাটা স্বচ্ছতা ও সতর্কতা'}
          </p>
          <p className="text-slate-400 leading-relaxed text-[11px]">
            {lang === 'en'
              ? 'Times are displayed in Coordinated Universal Time (UTC). Economic indicators are verified historical and scheduled calendar benchmarks. During high-impact "Red Folder" releases (such as NFP or FOMC), liquidity dries up and broker spreads widen dramatically. It is strongly advised for retail traders to avoid opening new positions 15 minutes before and after major announcements.'
              : 'সকল সময় আন্তর্জাতিক UTC তে প্রদর্শিত। হাই-ইমপ্যাক্ট রেড ফোল্ডার নিউজ রিলিজের সময় স্প্রেড ও স্লিপেজ মারাত্মক বৃদ্ধি পায়। নতুন ট্রেডারদের নিউজ প্রকাশের ১৫ মিনিট পূর্বে ও পরে ট্রেড থেকে বিরত থাকার জোরালো পরামর্শ দেওয়া হয়।'}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0F172A] p-4 rounded-xl border border-slate-800">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 mr-2">
            <Filter className="w-3.5 h-3.5" />
            Impact Level:
          </span>

          {['all', 'HIGH', 'MEDIUM', 'LOW'].map(imp => (
            <button
              key={imp}
              onClick={() => setFilterImpact(imp)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                filterImpact === imp
                  ? imp === 'HIGH' ? 'bg-red-500 text-white font-bold' : 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {imp === 'all' ? 'All Impacts' : imp}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Currency:</span>
          <select
            value={filterCurrency}
            onChange={e => setFilterCurrency(e.target.value)}
            className="bg-[#0a0f1d] border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-hidden"
          >
            <option value="all">All Currencies</option>
            <option value="USD">USD (US Dollar)</option>
            <option value="EUR">EUR (Euro)</option>
            <option value="GBP">GBP (British Pound)</option>
            <option value="AUD">AUD (Aussie)</option>
            <option value="JPY">JPY (Yen)</option>
          </select>
        </div>
      </div>

      {/* Calendar Event Cards */}
      <div className="space-y-3">
        {filteredEvents.map(ev => {
          const isHigh = ev.impact === 'HIGH';
          const isMedium = ev.impact === 'MEDIUM';

          return (
            <div
              key={ev.id}
              className={`bg-[#0F172A] border rounded-2xl p-5 transition-colors shadow-lg ${
                isHigh ? 'border-red-900/40 bg-radial from-red-950/10 to-[#0F172A]' : 'border-slate-800'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start sm:items-center gap-3">
                  {/* Currency Tag */}
                  <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 font-mono font-bold text-xs text-white shrink-0">
                    {ev.currency}
                  </span>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase ${
                        isHigh ? 'bg-red-950 text-red-400 border-red-800/60' :
                        isMedium ? 'bg-amber-950 text-amber-400 border-amber-800/60' :
                        'bg-slate-900 text-slate-400 border-slate-800'
                      }`}>
                        {ev.impact} Impact
                      </span>
                      <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-emerald-400" />
                        {ev.time}
                      </span>
                    </div>

                    <h3 className="text-sm sm:text-base font-bold text-white mt-1">
                      {lang === 'en' ? ev.eventEn : ev.eventBn}
                    </h3>
                  </div>
                </div>

                {/* Metrics */}
                <div className="flex items-center gap-4 text-xs font-mono self-end sm:self-auto bg-[#0a0f1d] px-3.5 py-2 rounded-xl border border-slate-800">
                  <div>
                    <p className="text-[10px] text-slate-500 font-sans">Actual</p>
                    <p className="font-bold text-emerald-400">{ev.actual || '--'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 font-sans">Forecast</p>
                    <p className="font-bold text-slate-300">{ev.forecast || '--'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 font-sans">Previous</p>
                    <p className="font-bold text-slate-400">{ev.previous || '--'}</p>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="mt-3 pt-3 border-t border-slate-800/60 text-xs text-slate-400 leading-relaxed">
                <p>{lang === 'en' ? ev.descriptionEn : ev.descriptionBn}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
