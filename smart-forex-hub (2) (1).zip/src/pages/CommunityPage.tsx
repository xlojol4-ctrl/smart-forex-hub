import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import type { CommunityPost } from '../types/index.ts';
import { 
  Users, MessageSquare, Plus, ThumbsUp, Flag, Search, 
  Send, Shield, CheckCircle2, AlertTriangle, Lock
} from 'lucide-react';

export const CommunityPage: React.FC = () => {
  const { user, token, openAuthModal, getAuthHeaders, isAdmin } = useAuth();
  const { lang, t } = useLanguage();

  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activePostComments, setActivePostComments] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState('');

  // Create Post Modal
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<'beginner' | 'strategy' | 'technical' | 'psychology' | 'brokers'>('beginner');

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/community/posts', {
        headers: getAuthHeaders()
      });
      if (res.ok) {
        const data = await res.json();
        setPosts(data.posts || []);
      }
    } catch (e) {
      console.error('Failed to fetch posts:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      openAuthModal('login');
      return;
    }
    if (!newTitle.trim() || !newContent.trim()) return;

    try {
      const res = await fetch('/api/community/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          title: newTitle,
          content: newContent,
          category: newCategory
        })
      });

      if (res.ok) {
        setIsCreateOpen(false);
        setNewTitle('');
        setNewContent('');
        fetchPosts();
      }
    } catch (e) {
      console.error('Error creating post:', e);
    }
  };

  const handleAddComment = async (postId: string) => {
    if (!token) {
      openAuthModal('login');
      return;
    }
    if (!commentInput.trim()) return;

    try {
      const res = await fetch(`/api/community/posts/${postId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ content: commentInput })
      });

      if (res.ok) {
        setCommentInput('');
        fetchPosts();
      }
    } catch (e) {
      console.error('Error adding comment:', e);
    }
  };

  const handleReportPost = async (postId: string) => {
    if (!token) {
      openAuthModal('login');
      return;
    }
    if (!confirm('Report this post to platform moderators for review?')) return;

    try {
      const res = await fetch(`/api/community/posts/${postId}/report`, {
        method: 'POST',
        headers: getAuthHeaders()
      });
      if (res.ok) {
        alert('Thank you. This post has been flagged for administrator review.');
        fetchPosts();
      }
    } catch (e) {
      console.error('Error reporting post:', e);
    }
  };

  const filteredPosts = posts.filter(p => {
    if (selectedCategory !== 'all' && p.category !== selectedCategory) return false;
    const q = searchQuery.toLowerCase();
    return p.title.toLowerCase().includes(q) || p.content.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-8 py-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
            <Users className="w-4 h-4" />
            <span>Forex Learning Forum</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            {t.communityTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            {t.communitySubtitle}
          </p>
        </div>

        <button
          onClick={() => {
            if (!token) openAuthModal('login');
            else setIsCreateOpen(true);
          }}
          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-lg shadow-emerald-500/20 flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>{t.communityNewPost}</span>
        </button>
      </div>

      {/* Forum Notice */}
      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs text-slate-400">
        <span>
          <strong>Community Guidelines:</strong> Only educational discussions and study questions are permitted. Unsolicited signal promotion, affiliate links, and commercial solicitation are strictly prohibited and immediately banned.
        </span>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search discussions, questions, setups..."
            className="w-full bg-[#0F172A] border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[#0F172A] border border-slate-800 rounded-xl overflow-x-auto scrollbar-none">
          {[
            { id: 'all', label: 'All Topics' },
            { id: 'beginner', label: 'Beginner' },
            { id: 'strategy', label: 'Strategy' },
            { id: 'technical', label: 'Technical' },
            { id: 'psychology', label: 'Psychology' },
            { id: 'brokers', label: 'Brokers/Exness' },
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Feed List */}
      <div className="space-y-4">
        {filteredPosts.map(post => {
          const isCommentsOpen = activePostComments === post.id;
          return (
            <div
              key={post.id}
              className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 text-emerald-400 flex items-center justify-center font-bold text-xs font-mono">
                    {post.userName.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">{post.userName}</span>
                      {post.userRole === 'admin' && (
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30 font-semibold">
                          STAFF / ADMIN
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {new Date(post.createdAt).toLocaleDateString()} · Category: {post.category}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleReportPost(post.id)}
                  className="text-slate-500 hover:text-red-400 p-1 text-xs transition-colors flex items-center gap-1"
                  title="Report inappropriate content"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Report</span>
                </button>
              </div>

              <div className="space-y-1.5">
                <h3 className="text-base font-bold text-white">{post.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                  {post.content}
                </p>
              </div>

              {/* Actions & Comment toggle */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs text-slate-400">
                <button
                  onClick={() => setActivePostComments(isCommentsOpen ? null : post.id)}
                  className="flex items-center gap-1.5 hover:text-emerald-400 transition-colors font-medium"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{post.comments?.length || post.commentsCount || 0} {t.communityComments}</span>
                </button>
              </div>

              {/* Comment Thread Drawer */}
              {isCommentsOpen && (
                <div className="mt-4 pt-4 border-t border-slate-800/60 space-y-3 bg-[#0a0f1d] p-4 rounded-xl">
                  <div className="space-y-2.5">
                    {post.comments && post.comments.length > 0 ? (
                      post.comments.map(c => (
                        <div key={c.id} className="p-3 bg-slate-900/60 rounded-lg border border-slate-800 text-xs space-y-1">
                          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                            <span className="text-emerald-300 font-semibold">{c.userName}</span>
                            <span className="font-mono text-[10px] text-slate-500">{new Date(c.createdAt).toLocaleDateString()}</span>
                          </div>
                          <p className="text-slate-200">{c.content}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-500 italic">No comments yet on this discussion.</p>
                    )}
                  </div>

                  {/* Add comment input */}
                  {user ? (
                    <div className="flex gap-2 pt-2">
                      <input
                        type="text"
                        value={commentInput}
                        onChange={e => setCommentInput(e.target.value)}
                        placeholder={t.communityReply}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden"
                      />
                      <button
                        type="button"
                        onClick={() => handleAddComment(post.id)}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-lg text-xs"
                      >
                        Reply
                      </button>
                    </div>
                  ) : (
                    <div className="pt-2 text-center text-xs text-slate-500">
                      Please <button onClick={() => openAuthModal('login')} className="text-emerald-400 underline">Sign In</button> to reply.
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {filteredPosts.length === 0 && (
          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-2">
            <Users className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-sm font-semibold text-slate-300">No discussions found</p>
            <p className="text-xs text-slate-500">Be the first to create a topic in this category!</p>
          </div>
        )}
      </div>

      {/* Create Post Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-[#0F172A] border border-slate-800 rounded-2xl p-6 shadow-2xl text-slate-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-lg font-bold text-white">{t.communityNewPost}</h3>
              <button onClick={() => setIsCreateOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-medium">Topic Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="e.g. How to manage risk when trading London open breakout?"
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2.5 text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Category</label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as any)}
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2 text-white focus:outline-hidden"
                >
                  <option value="beginner">Beginner Questions</option>
                  <option value="strategy">Strategy Discussion</option>
                  <option value="technical">Technical Analysis & Setups</option>
                  <option value="psychology">Trading Psychology</option>
                  <option value="brokers">Brokers & Exness Setup</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Detailed Explanation</label>
                <textarea
                  rows={5}
                  required
                  value={newContent}
                  onChange={e => setNewContent(e.target.value)}
                  placeholder="Explain your question or educational observation in detail. Please do NOT post commercial links or signal promos."
                  className="w-full bg-[#0a0f1d] border border-slate-700 rounded-lg p-2.5 text-white focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl"
                >
                  Publish Post
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
